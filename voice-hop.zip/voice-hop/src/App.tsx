// App shell: switches between the two games.
// If you do not have src/games/takeoff/, delete the takeoff import, the CSS import
// and the Take off button below, and set the initial game to "voicehop".
import { useState } from "react";
import TakeoffGame from "./games/takeoff/TakeoffGame";
import VoiceHopGame from "./games/voicehop/VoiceHopGame";
import "./games/takeoff/takeoff.css";
import "./games/voicehop/voicehop.css";
import "./app.css";

type GameId = "takeoff" | "voicehop";

export default function App() {
  const [game, setGame] = useState<GameId>("voicehop");
  return (
    <main className="app">
      <div className="app-wrap">
        <nav className="app-tabs" aria-label="Choose a game">
          <button className={game === "takeoff" ? "on" : ""} onClick={() => setGame("takeoff")}>✈ Take off</button>
          <button className={game === "voicehop" ? "on" : ""} onClick={() => setGame("voicehop")}>🌱 Voice Hop</button>
        </nav>
        {game === "takeoff" ? <TakeoffGame maxSeconds={15} /> : <VoiceHopGame />}
      </div>
    </main>
  );
}
