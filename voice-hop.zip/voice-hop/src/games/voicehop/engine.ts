// Game rules and physics for "Voice Hop". Pure logic: no drawing, no audio.
// Units are tiles (1 tile = 1 unit) and seconds; y grows downwards.

import { buildLevelRows, HINTS, ROWS } from "./level";
import type { CommandType } from "./voice";

export type Difficulty = "gentle" | "normal" | "fast";
export type GameState = "playing" | "won" | "over";

export interface GameEvent {
  type: "jump" | "double" | "slash" | "dash" | "stomp" | "break" | "seed" | "hurt" | "fall" | "checkpoint" | "win" | "kill" | "crumble";
  x: number;
  y: number;
}

export interface Enemy {
  kind: "blob" | "beetle";
  x: number; y: number; w: number; h: number;
  vx: number; vy: number;
  homeX: number;
  alive: boolean;
  t: number;
  deadT: number;
}

export interface Seed { x: number; y: number; taken: boolean }
export interface Lantern { x: number; y: number; lit: boolean }
export interface Sign { x: number; y: number; id: string }
export interface Marker { x: number; used: boolean; enemy: Enemy | null; hint: string }

export interface Player {
  x: number; y: number; w: number; h: number;
  vx: number; vy: number;
  onGround: boolean;
  jumpsLeft: number;
  coyote: number;
  buffer: number;
  dashT: number;
  dashCool: number;
  slashT: number;
  slashCool: number;
  invuln: number;
  knockT: number;
  runPhase: number;
  waiting: boolean;
  justJumped: number;
  /** column of the wall or crate Pip is pushing against, or -1 */
  blockedBy: number;
}

const GRAVITY = 34;
const JUMP_V = 13.5;
const DOUBLE_V = 12;
const MAX_FALL = 18;
const AIR_SPEED = 3.8;
const DASH_SPEED = 10;
const DASH_BASE = 0.34;
const DASH_MORE = 0.16;
const DASH_MAX = 1.2;
const SLASH_TIME = 0.3;
const SLASH_REACH = 1.8;
const COYOTE = 0.12;
const BUFFER = 0.18;
const CRUMBLE_DELAY = 0.3;

const RUN_SPEED: Record<Difficulty, number> = { gentle: 3.0, normal: 3.6, fast: 4.6 };

export class Game {
  readonly difficulty: Difficulty;
  readonly w: number;
  readonly h = ROWS;
  tiles: string[][];
  readonly original: string[][];
  player: Player;
  enemies: Enemy[] = [];
  seeds: Seed[] = [];
  lanterns: Lantern[] = [];
  signs: Sign[] = [];
  markers: Marker[] = [];
  goal = { x: 0, y: 0 };
  crumble = new Map<string, number>(); // "x,y" -> seconds since first stepped on
  state: GameState = "playing";
  time = 0;
  hearts = 3;
  readonly maxHearts = 3;
  falls = 0;
  respawn = { x: 1, y: 9 };
  camX = 0;
  events: GameEvent[] = [];
  counts: Record<CommandType, number> = { jump: 0, slash: 0, dash: 0, dashMore: 0 };
  private queue: CommandType[] = [];
  private lastMoveAt = -9;

  constructor(difficulty: Difficulty) {
    this.difficulty = difficulty;
    const rows = buildLevelRows();
    this.w = rows[0].length;
    this.original = rows.map((r) => r.split(""));
    this.tiles = this.original.map((r) => [...r]);
    let start = { x: 1, y: 9 };
    for (let y = 0; y < this.h; y++) {
      for (let x = 0; x < this.w; x++) {
        const c = this.tiles[y][x];
        let keep = false;
        if (c === "P") start = { x, y };
        else if (c === "*") this.seeds.push({ x: x + 0.5, y: y + 0.5, taken: false });
        else if (c === "B") this.enemies.push(this.makeEnemy("blob", x, y));
        else if (c === "S") this.enemies.push(this.makeEnemy("beetle", x, y));
        else if (c === "L") this.lanterns.push({ x, y, lit: false });
        else if (c === "G") this.goal = { x, y };
        else if (c === "w") this.markers.push({ x: x + 1, used: false, enemy: null, hint: "" });
        else if (c in HINTS) this.signs.push({ x, y, id: c });
        else keep = true;
        if (!keep) this.tiles[y][x] = ".";
      }
    }
    this.respawn = { x: start.x + 0.15, y: start.y + 0.1 };
    // what is each Gentle-mode waiting spot waiting for?
    for (const m of this.markers) {
      m.enemy = this.enemies.find((en) => en.homeX >= m.x - 0.2 && en.homeX < m.x + 3) ?? null;
      let gap = 0;
      for (let x = m.x; x < m.x + 8 && this.tile(x, 10) !== "#"; x++) gap++;
      m.hint = m.enemy ? "Say “kaa” to slash"
        : this.tile(m.x, 10) === "~" || gap >= 3 ? "Say “ta-ta-ta-ta” to dash"
          : "Say “paa” to jump";
    }
    this.player = this.newPlayer(this.respawn.x, this.respawn.y);
  }

  get runSpeed() { return RUN_SPEED[this.difficulty]; }
  get seedsTaken() { return this.seeds.filter((s) => s.taken).length; }
  get progress() { return Math.max(0, Math.min(1, this.player.x / (this.goal.x || 1))); }

  private makeEnemy(kind: Enemy["kind"], x: number, y: number): Enemy {
    const w = kind === "blob" ? 0.85 : 0.9, h = kind === "blob" ? 0.7 : 0.62;
    return { kind, x: x + (1 - w) / 2, y: y + 1 - h, w, h, vx: kind === "beetle" ? -0.9 : 0, vy: 0, homeX: x + (1 - w) / 2, alive: true, t: Math.random() * 2, deadT: 0 };
  }

  private newPlayer(x: number, y: number): Player {
    return { x, y, w: 0.7, h: 0.9, vx: 0, vy: 0, onGround: false, jumpsLeft: 1, coyote: 0, buffer: 0, dashT: 0, dashCool: 0, slashT: 0, slashCool: 0, invuln: 0, knockT: 0, runPhase: 0, waiting: false, justJumped: 0, blockedBy: -1 };
  }

  /** Queue a command (from the voice detector or keyboard); applied on the next step. */
  command(type: CommandType) {
    if (this.state === "playing") this.queue.push(type);
  }

  private emit(type: GameEvent["type"], x: number, y: number) { this.events.push({ type, x, y }); }

  tile(x: number, y: number): string {
    if (x < 0 || x >= this.w) return "#";
    if (y < 0 || y >= this.h) return ".";
    return this.tiles[y][x];
  }
  private solid(x: number, y: number) { const c = this.tile(x, y); return c === "#" || c === "C"; }
  private oneWay(x: number, y: number) {
    const c = this.tile(x, y);
    return c === "=" || (c === "~" && (this.crumble.get(`${x},${y}`) ?? 0) < CRUMBLE_DELAY);
  }

  private doJump(p: Player): boolean {
    if (p.onGround || p.coyote > 0) {
      p.vy = -JUMP_V; p.onGround = false; p.coyote = 0; p.jumpsLeft = 1; p.justJumped = 0.1; p.dashT = 0;
      this.emit("jump", p.x + p.w / 2, p.y + p.h);
      return true;
    }
    if (p.jumpsLeft > 0) {
      p.vy = -DOUBLE_V; p.jumpsLeft--; p.dashT = 0; p.justJumped = 0.1;
      this.emit("double", p.x + p.w / 2, p.y + p.h);
      return true;
    }
    return false;
  }

  private apply(cmd: CommandType) {
    const p = this.player;
    this.counts[cmd]++;
    // in Gentle mode a jump or dash sends Pip on from a waiting spot
    // (a slash at an enemy also does, once the enemy is gone; see step())
    if (cmd !== "slash") {
      this.lastMoveAt = this.time;
      if (p.waiting) this.releaseWait();
    }
    if (cmd === "jump") {
      if (!this.doJump(p)) p.buffer = BUFFER;
    } else if (cmd === "slash") {
      if (p.slashCool <= 0) {
        p.slashT = SLASH_TIME; p.slashCool = 0.12;
        this.emit("slash", p.x + p.w, p.y + p.h / 2);
      }
    } else if (cmd === "dash") {
      if (p.dashT > 0) p.dashT = Math.min(DASH_MAX, p.dashT + DASH_MORE);
      else if (p.dashCool <= 0) {
        p.dashT = DASH_BASE; p.vy = 0;
        this.emit("dash", p.x, p.y + p.h / 2);
      }
    } else if (cmd === "dashMore") {
      if (p.dashT > 0) p.dashT = Math.min(DASH_MAX, p.dashT + DASH_MORE);
      else if (p.dashCool <= 0) { p.dashT = DASH_BASE; p.vy = 0; this.emit("dash", p.x, p.y + p.h / 2); }
    }
  }

  private waitingMarker(): Marker | undefined {
    const p = this.player;
    return this.markers.find((mk) => !mk.used && Math.abs(p.x + p.w - mk.x) < 0.6);
  }

  private releaseWait() {
    const m = this.waitingMarker();
    if (m) m.used = true;
    this.player.waiting = false;
  }

  /** What Pip is waiting for (Gentle mode) or pushing against, or null. */
  waitHint(): string | null {
    const p = this.player;
    if (p.waiting) return this.waitingMarker()?.hint ?? "Say a command";
    if (p.blockedBy >= 0 && p.onGround) {
      const x = p.blockedBy, base = Math.floor(p.y + p.h - 0.01);
      if (this.tile(x, base) === "C") return "Say “kaa” to slash the crate";
      let hgt = 0;
      for (let y = base; y >= 0 && this.solid(x, y); y--) hgt++;
      return hgt >= 3 ? "Too tall! Say “paa-paa” to double jump" : "Say “paa” to jump";
    }
    return null;
  }

  private hurt(fromX: number) {
    const p = this.player;
    if (p.invuln > 0 || p.dashT > 0) return;
    this.hearts--;
    this.emit("hurt", p.x + p.w / 2, p.y + p.h / 2);
    p.invuln = 1.5; p.knockT = 0.25; p.vy = -7;
    p.vx = fromX > p.x ? -3 : 3;
    if (this.hearts <= 0) this.lose();
  }

  private lose() {
    if (this.difficulty === "gentle") { this.hearts = this.maxHearts; return; }
    this.hearts = 0;
    this.state = "over";
  }

  private fellOff() {
    this.falls++;
    this.hearts--;
    this.emit("fall", this.player.x, this.h - 1);
    if (this.hearts <= 0) { this.lose(); if (this.state === "over") return; }
    this.crumble.clear();
    const p = this.newPlayer(this.respawn.x, this.respawn.y);
    p.invuln = 1.2;
    this.player = p;
    // markers ahead of the checkpoint wait again
    this.markers.forEach((m) => { if (m.x > this.respawn.x) m.used = false; });
  }

  step(dt: number) {
    if (this.state !== "playing") return;
    this.time += dt;
    const p = this.player;
    p.invuln = Math.max(0, p.invuln - dt);
    p.knockT = Math.max(0, p.knockT - dt);
    p.slashT = Math.max(0, p.slashT - dt);
    p.slashCool = Math.max(0, p.slashCool - dt);
    p.dashCool = Math.max(0, p.dashCool - dt);
    p.coyote = Math.max(0, p.coyote - dt);
    p.buffer = Math.max(0, p.buffer - dt);
    p.justJumped = Math.max(0, p.justJumped - dt);
    if (p.dashT > 0) { p.dashT -= dt; if (p.dashT <= 0) { p.dashT = 0; p.dashCool = 0.15; } }

    for (const c of this.queue.splice(0)) this.apply(c);

    // Gentle mode: keep waiting until released (see apply) or the enemy ahead is gone
    if (p.waiting) {
      const m = this.waitingMarker();
      if (!m || (m.enemy && !m.enemy.alive && m.enemy.deadT > 0.25)) this.releaseWait();
    }

    // horizontal speed
    if (p.knockT > 0) { /* keep knockback velocity */ }
    else if (p.dashT > 0) p.vx = DASH_SPEED;
    else if (p.waiting) p.vx = 0;
    else p.vx = p.onGround ? this.runSpeed : Math.max(this.runSpeed, AIR_SPEED);

    // vertical speed
    if (p.dashT > 0) p.vy = 0;
    else p.vy = Math.min(MAX_FALL, p.vy + GRAVITY * dt);

    // move and collide, X then Y
    const prevRight = p.x + p.w;
    p.blockedBy = -1;
    p.x += p.vx * dt;
    this.collideX(p);
    // Gentle mode: stop at each "wait here" spot until the player says something
    if (this.difficulty === "gentle" && p.onGround && p.dashT <= 0 && !p.waiting) {
      for (const m of this.markers) {
        if (m.used) continue;
        if (prevRight <= m.x + 0.001 && p.x + p.w >= m.x) {
          // no need to wait if the player already jumped/dashed just before, or the enemy is gone
          if (this.time - this.lastMoveAt < 1 || (m.enemy && !m.enemy.alive)) { m.used = true; continue; }
          p.x = m.x - p.w;
          p.waiting = true;
          break;
        }
        if (p.x + p.w > m.x + 0.6) m.used = true;
      }
    }
    const prevBottom = p.y + p.h;
    p.y += p.vy * dt;
    const wasGround = p.onGround;
    p.onGround = false;
    this.collideY(p, prevBottom);
    if (p.onGround) {
      p.jumpsLeft = 1;
      if (p.buffer > 0) { p.buffer = 0; this.doJump(p); }
    } else if (wasGround && p.vy >= 0) p.coyote = COYOTE;
    if (p.onGround) p.runPhase += dt * p.vx * 2.2;

    // crumbling bridge
    if (p.onGround) {
      const by = Math.floor(p.y + p.h + 0.01);
      for (let tx = Math.floor(p.x); tx <= Math.floor(p.x + p.w - 0.001); tx++) {
        if (this.tile(tx, by) === "~") {
          const k = `${tx},${by}`;
          if (!this.crumble.has(k)) { this.crumble.set(k, 0); this.emit("crumble", tx + 0.5, by); }
        }
      }
    }
    for (const [k, t] of this.crumble) this.crumble.set(k, t + dt);

    // thorns hurt when touched
    for (let ty = Math.floor(p.y); ty <= Math.floor(p.y + p.h - 0.001); ty++) {
      for (let tx = Math.floor(p.x + 0.08); tx <= Math.floor(p.x + p.w - 0.08); tx++) {
        if (this.tile(tx, ty) === "^" && p.y + p.h > ty + 0.45) this.hurt(tx + 0.5);
      }
    }

    this.updateEnemies(dt);
    this.slashHits();

    // seeds, lanterns, goal
    const cx = p.x + p.w / 2, cy = p.y + p.h / 2;
    for (const s of this.seeds) {
      if (!s.taken && Math.abs(s.x - cx) < 0.65 && Math.abs(s.y - cy) < 0.75) { s.taken = true; this.emit("seed", s.x, s.y); }
    }
    for (const l of this.lanterns) {
      if (!l.lit && cx > l.x + 0.3) {
        l.lit = true;
        this.respawn = { x: l.x + 0.6, y: l.y + 0.1 };
        this.emit("checkpoint", l.x + 0.5, l.y);
      }
    }
    if (cx > this.goal.x + 0.4) {
      this.state = "won";
      this.emit("win", this.goal.x + 0.5, this.goal.y);
    }

    if (p.y > this.h + 1) this.fellOff();
    this.camX = Math.max(0, p.x - 4.5);
  }

  private collideX(p: Player) {
    const top = Math.floor(p.y + 0.02), bottom = Math.floor(p.y + p.h - 0.02);
    if (p.vx > 0) {
      const tx = Math.floor(p.x + p.w);
      for (let ty = top; ty <= bottom; ty++) {
        if (this.solid(tx, ty)) {
          if (p.dashT > 0 && this.tile(tx, ty) === "C") { this.breakCrate(tx, ty); continue; }
          p.x = tx - p.w;
          p.vx = 0;
          p.blockedBy = tx;
          break;
        }
      }
    } else if (p.vx < 0) {
      const tx = Math.floor(p.x);
      for (let ty = top; ty <= bottom; ty++) if (this.solid(tx, ty)) { p.x = tx + 1; p.vx = 0; break; }
    }
  }

  private collideY(p: Player, prevBottom: number) {
    const left = Math.floor(p.x + 0.02), right = Math.floor(p.x + p.w - 0.02);
    if (p.vy > 0) {
      const ty = Math.floor(p.y + p.h);
      for (let tx = left; tx <= right; tx++) {
        if (this.solid(tx, ty) || (this.oneWay(tx, ty) && prevBottom <= ty + 0.05)) {
          p.y = ty - p.h; p.vy = 0; p.onGround = true;
          return;
        }
      }
    } else if (p.vy < 0) {
      const ty = Math.floor(p.y);
      for (let tx = left; tx <= right; tx++) if (this.solid(tx, ty)) { p.y = ty + 1; p.vy = 0; return; }
    } else {
      // standing still vertically: check we still have ground (dashing hovers anyway)
      const ty = Math.floor(p.y + p.h + 0.02);
      for (let tx = left; tx <= right; tx++) {
        if (this.solid(tx, ty) || this.oneWay(tx, ty)) { if (p.dashT <= 0) p.onGround = true; return; }
      }
    }
  }

  private breakCrate(tx: number, ty: number) {
    this.tiles[ty][tx] = ".";
    this.emit("break", tx + 0.5, ty + 0.5);
  }

  private kill(e: Enemy) {
    e.alive = false;
    e.deadT = 0;
    this.emit("kill", e.x + e.w / 2, e.y + e.h / 2);
  }

  private updateEnemies(dt: number) {
    const p = this.player;
    for (const e of this.enemies) {
      if (!e.alive) { e.deadT += dt; continue; }
      if (Math.abs(e.x - p.x) > 14) continue; // asleep until Pip is near
      e.t += dt;
      if (e.kind === "blob") {
        // little hops on the spot
        e.vy += GRAVITY * 0.6 * dt;
        e.y += e.vy * dt;
        const floor = Math.floor(e.y + e.h);
        if (this.solid(Math.floor(e.x + e.w / 2), floor) && e.vy > 0) { e.y = floor - e.h; e.vy = 0; }
        if (e.vy === 0 && e.t > 1.4) { e.vy = -5; e.t = 0; }
      } else {
        // beetles patrol a short way either side of home and turn at walls and edges
        const nx = e.x + e.vx * dt;
        const ahead = e.vx > 0 ? Math.floor(nx + e.w) : Math.floor(nx);
        const footY = Math.floor(e.y + e.h + 0.05);
        const blocked = this.solid(ahead, Math.floor(e.y + e.h / 2)) || !this.solid(ahead, footY);
        if (blocked || Math.abs(nx - e.homeX) > 0.7) e.vx = -e.vx;
        else e.x = nx;
      }
      // touching Pip
      if (p.x < e.x + e.w && p.x + p.w > e.x && p.y < e.y + e.h && p.y + p.h > e.y) {
        const stomp = e.kind === "blob" && p.vy > 0 && p.y + p.h - e.y < 0.4;
        if (p.dashT > 0) this.kill(e);
        else if (stomp) {
          this.kill(e);
          p.vy = -10; p.jumpsLeft = 1;
          this.emit("stomp", e.x + e.w / 2, e.y);
        } else this.hurt(e.x + e.w / 2);
      }
    }
  }

  private slashHits() {
    const p = this.player;
    if (p.slashT <= SLASH_TIME - 0.2 || p.slashT <= 0) return; // only the first 0.2 s of the swing hits
    const x0 = p.x + p.w * 0.4, x1 = p.x + p.w + SLASH_REACH, y0 = p.y - 0.35, y1 = p.y + p.h + 0.15;
    for (const e of this.enemies) {
      if (e.alive && e.x < x1 && e.x + e.w > x0 && e.y < y1 && e.y + e.h > y0) this.kill(e);
    }
    for (let ty = Math.floor(y0); ty <= Math.floor(y1 - 0.01); ty++) {
      for (let tx = Math.floor(x0); tx <= Math.floor(x1); tx++) if (this.tile(tx, ty) === "C") this.breakCrate(tx, ty);
    }
  }

  /** Hint shown near a sign (or while waiting in Gentle mode). */
  nearbyHint(): { say: string; text: string } | null {
    const p = this.player;
    const s = [...this.signs].reverse().find((sg) => p.x >= sg.x - 1 && p.x <= sg.x + 9);
    return s ? HINTS[s.id] : null;
  }
}
