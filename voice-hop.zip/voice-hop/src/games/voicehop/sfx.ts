// Tiny synthesized sound effects (no audio files needed).
// play() returns how long the sound lasts so the voice detector can ignore it.

import type { GameEvent } from "./engine";

export function createSfx() {
  let ctx: AudioContext | null = null;
  let master: GainNode | null = null;
  let enabled = true;

  const ensure = () => {
    if (!ctx) {
      ctx = new AudioContext();
      master = ctx.createGain();
      master.gain.value = 0.18;
      master.connect(ctx.destination);
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  };

  function tone(freq: number, to: number, dur: number, type: OscillatorType, vol = 1, delay = 0) {
    const c = ensure();
    const t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, to), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master!);
    o.start(t); o.stop(t + dur + 0.02);
  }

  function noise(dur: number, freq: number, q: number, vol = 1, sweepTo?: number) {
    const c = ensure();
    const n = Math.floor(c.sampleRate * dur);
    const buf = c.createBuffer(1, n, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    const src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    src.buffer = buf;
    f.type = "bandpass"; f.Q.value = q;
    f.frequency.setValueAtTime(freq, c.currentTime);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, c.currentTime + dur);
    g.gain.setValueAtTime(vol, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
    src.connect(f); f.connect(g); g.connect(master!);
    src.start();
  }

  /** Plays the sound for a game event; returns its length in seconds (0 if silent). */
  function play(type: GameEvent["type"]): number {
    if (!enabled) return 0;
    switch (type) {
      case "jump": tone(320, 640, 0.12, "square", 0.35); return 0.12;
      case "double": tone(520, 1040, 0.12, "square", 0.3); tone(780, 1400, 0.08, "triangle", 0.25, 0.04); return 0.14;
      case "slash": noise(0.12, 2500, 1.2, 0.8, 900); return 0.12;
      case "dash": noise(0.22, 600, 0.8, 0.7, 2400); return 0.22;
      case "stomp": tone(220, 90, 0.12, "sine", 0.8); return 0.12;
      case "kill": tone(600, 200, 0.14, "triangle", 0.5); return 0.14;
      case "break": noise(0.16, 500, 0.9, 0.9, 200); return 0.16;
      case "seed": tone(1320, 1320, 0.09, "sine", 0.4); tone(1760, 1760, 0.12, "sine", 0.35, 0.06); return 0.18;
      case "hurt": tone(400, 120, 0.25, "sawtooth", 0.35); return 0.25;
      case "fall": tone(500, 80, 0.45, "triangle", 0.4); return 0.45;
      case "checkpoint": [660, 880, 1100].forEach((f, i) => tone(f, f, 0.12, "triangle", 0.35, i * 0.08)); return 0.34;
      case "win": [523, 659, 784, 1047].forEach((f, i) => tone(f, f, 0.22, "triangle", 0.4, i * 0.12)); return 0.6;
      default: return 0;
    }
  }

  return {
    play,
    unlock: () => { if (enabled) ensure(); },
    setEnabled: (on: boolean) => { enabled = on; },
    close: () => { ctx?.close().catch(() => {}); ctx = null; master = null; },
  };
}
