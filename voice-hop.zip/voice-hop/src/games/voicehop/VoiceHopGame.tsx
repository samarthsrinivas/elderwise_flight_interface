// "Voice Hop": a side-scrolling platformer you play with your voice.
//   "paa" jump · "paa-paa" double jump · "kaa" slash · "ta-ta-ta-ta" dash
// Keyboard works too: Space/↑ jump, X slash, Shift dash, Esc pause.

import { useCallback, useEffect, useRef, useState } from "react";
import { Game } from "./engine";
import type { Difficulty } from "./engine";
import { createRenderer } from "./render";
import { createSfx } from "./sfx";
import {
  classify, closeVoiceMic, CommandMapper, loadModel, openVoiceMic, saveModel, SyllableDetector, trainModel,
} from "./voice";
import type { CommandType, Phoneme, Syllable, VoiceMic, VoiceModel } from "./voice";

type Screen = "menu" | "calibrate" | "playing" | "paused" | "won" | "over";
type CalStage = "quiet" | Phoneme | "test";

interface Settings { difficulty: Difficulty; sound: boolean; sensitivity: number }

const SETTINGS_KEY = "voicehop.settings.v1";
const CAL_N = 4;
const PHONEME_SAY: Record<Phoneme, string> = { pa: "PAA", ka: "KAA", ta: "TA" };
const DIFFICULTIES: { id: Difficulty; name: string; note: string }[] = [
  { id: "gentle", name: "Gentle", note: "Pip waits for you at each obstacle. No game over." },
  { id: "normal", name: "Normal", note: "Pip keeps running. 3 hearts." },
  { id: "fast", name: "Fast", note: "Quicker running for confident players." },
];

function loadSettings(): Settings {
  const d: Settings = { difficulty: "gentle", sound: true, sensitivity: 14 };
  try { return { ...d, ...(JSON.parse(localStorage.getItem(SETTINGS_KEY) ?? "{}") as Partial<Settings>) }; } catch { return d; }
}
function saveSettings(s: Settings) { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch { /* ignore */ } }
function loadBest(d: Difficulty): { time: number; seeds: number } | null {
  try { return JSON.parse(localStorage.getItem(`voicehop.best.${d}`) ?? "null"); } catch { return null; }
}
function saveBest(d: Difficulty, b: { time: number; seeds: number }) { try { localStorage.setItem(`voicehop.best.${d}`, JSON.stringify(b)); } catch { /* ignore */ } }

const fmtTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

export default function VoiceHopGame() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [model, setModel] = useState<VoiceModel | null>(loadModel);
  const [micError, setMicError] = useState<string | null>(null);
  const [micOn, setMicOn] = useState(false);
  const [hud, setHud] = useState({ hearts: 3, seeds: 0, total: 0 });
  const [hint, setHint] = useState<string | null>(null);
  const [heard, setHeard] = useState<{ text: string; kind: CommandType; n: number } | null>(null);
  const [result, setResult] = useState<{ time: number; seeds: number; total: number; best: boolean; counts: Record<CommandType, number>; falls: number } | null>(null);
  const [cal, setCal] = useState<{ stage: CalStage; counts: Record<Phoneme, number>; last: Phoneme | null; accuracy: number | null }>({
    stage: "quiet", counts: { pa: 0, ka: 0, ta: 0 }, last: null, accuracy: null,
  });

  const screenRef = useRef<Screen>("menu");
  const gameRef = useRef<Game>(new Game(settings.difficulty));
  const rendererRef = useRef(createRenderer());
  const sfxRef = useRef(createSfx());
  const micRef = useRef<VoiceMic | null>(null);
  const detRef = useRef<SyllableDetector | null>(null);
  const mapperRef = useRef(new CommandMapper());
  const calRef = useRef<{ stage: CalStage; samples: { phoneme: Phoneme; features: number[] }[]; busy: boolean }>({ stage: "quiet", samples: [], busy: false });
  const settingsRef = useRef(settings);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const meterRef = useRef<HTMLDivElement>(null);
  const timeRef = useRef<HTMLSpanElement>(null);
  const progRef = useRef<HTMLDivElement>(null);
  const heardN = useRef(0);

  const go = (s: Screen) => { screenRef.current = s; setScreen(s); };

  useEffect(() => { settingsRef.current = settings; saveSettings(settings); sfxRef.current.setEnabled(settings.sound); if (detRef.current) detRef.current.sensitivity = settings.sensitivity; }, [settings]);

  /* ---------- voice ---------- */

  const onCalSyllable = useCallback((s: Syllable) => {
    const c = calRef.current;
    if (c.busy) return;
    if (c.stage === "test") { setCal((v) => ({ ...v, last: s.phoneme })); return; }
    if (c.stage === "quiet") return;
    const stage = c.stage;
    c.samples.push({ phoneme: stage, features: s.features });
    const n = c.samples.filter((x) => x.phoneme === stage).length;
    setCal((v) => ({ ...v, counts: { ...v.counts, [stage]: n } }));
    if (n >= CAL_N) {
      c.busy = true;
      window.setTimeout(() => {
        const next: CalStage = stage === "pa" ? "ka" : stage === "ka" ? "ta" : "test";
        if (next === "test") {
          const m = trainModel(c.samples);
          let ok = 0;
          if (m) c.samples.forEach((x) => { if (classify(x.features, m).phoneme === x.phoneme) ok++; });
          if (m && detRef.current) detRef.current.model = m;
          saveModel(m);
          setModel(m);
          setCal((v) => ({ ...v, stage: "test", accuracy: m ? ok / c.samples.length : null }));
        } else setCal((v) => ({ ...v, stage: next }));
        c.stage = next;
        c.busy = false;
      }, 700);
    }
  }, []);

  const onSyllable = useCallback((s: Syllable) => {
    const scr = screenRef.current;
    if (scr === "calibrate") { onCalSyllable(s); return; }
    if (scr !== "playing") return;
    const cmd = mapperRef.current.map(s);
    gameRef.current.command(cmd.type);
    rendererRef.current.say(cmd.label, cmd.type);
    setHeard({ text: cmd.label, kind: cmd.type, n: ++heardN.current });
  }, [onCalSyllable]);

  const ensureMic = useCallback(async (): Promise<boolean> => {
    if (micRef.current && detRef.current) return true;
    try {
      let det: SyllableDetector | null = null;
      const mic = await openVoiceMic((b) => det?.push(b));
      det = new SyllableDetector({ sampleRate: mic.ctx.sampleRate, onSyllable: (s) => onSyllable(s) });
      det.model = loadModel();
      det.sensitivity = settingsRef.current.sensitivity;
      micRef.current = mic;
      detRef.current = det;
      setMicOn(true);
      setMicError(null);
      // learn the room for a moment
      det.beginNoise();
      window.setTimeout(() => det?.finishNoise(), 1200);
      return true;
    } catch {
      setMicError("Microphone not available. Allow microphone access for this app (Windows: Settings ▸ Privacy & security ▸ Microphone), close other apps using it, then try again. You can still play with the keyboard.");
      return false;
    }
  }, [onSyllable]);

  /* ---------- game flow ---------- */

  const startGame = useCallback(() => {
    sfxRef.current.unlock();
    void ensureMic(); // the game starts right away; voice joins as soon as the mic is ready
    const g = new Game(settingsRef.current.difficulty);
    gameRef.current = g;
    rendererRef.current.reset();
    mapperRef.current.reset();
    setHud({ hearts: g.hearts, seeds: 0, total: g.seeds.length });
    setHeard(null);
    setResult(null);
    go("playing");
  }, [ensureMic]);

  const startCalibration = useCallback(async () => {
    sfxRef.current.unlock();
    const ok = await ensureMic();
    if (!ok) return;
    calRef.current = { stage: "quiet", samples: [], busy: false };
    setCal({ stage: "quiet", counts: { pa: 0, ka: 0, ta: 0 }, last: null, accuracy: null });
    go("calibrate");
    const det = detRef.current!;
    det.beginNoise();
    window.setTimeout(() => {
      det.finishNoise();
      calRef.current.stage = "pa";
      setCal((v) => ({ ...v, stage: "pa" }));
    }, 2000);
  }, [ensureMic]);

  const forgetVoice = () => {
    saveModel(null);
    setModel(null);
    if (detRef.current) detRef.current.model = null;
  };

  const finish = useCallback((g: Game) => {
    const won = g.state === "won";
    const total = g.seeds.length, seeds = g.seedsTaken;
    let best = false;
    if (won) {
      const prev = loadBest(g.difficulty);
      if (!prev || seeds > prev.seeds || (seeds === prev.seeds && g.time < prev.time)) { saveBest(g.difficulty, { time: g.time, seeds }); best = true; }
    }
    setResult({ time: g.time, seeds, total, best, counts: { ...g.counts }, falls: g.falls });
    go(won ? "won" : "over");
  }, []);

  /* ---------- keyboard ---------- */

  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      const scr = screenRef.current;
      if ((e.key === "Escape" || e.key === "p" || e.key === "P") && (scr === "playing" || scr === "paused")) {
        go(scr === "playing" ? "paused" : "playing");
        e.preventDefault();
        return;
      }
      if (scr !== "playing") return;
      const g = gameRef.current, r = rendererRef.current;
      let type: CommandType | null = null;
      if (e.key === " " || e.key === "ArrowUp" || e.key === "w" || e.key === "W") type = e.repeat ? null : "jump";
      else if (e.key === "x" || e.key === "X" || e.key === "k" || e.key === "K") type = e.repeat ? null : "slash";
      else if (e.key === "Shift" || e.key === "d" || e.key === "D") type = e.repeat ? "dashMore" : "dash";
      if (!type) return;
      e.preventDefault();
      g.command(type);
      if (!e.repeat) r.say(type === "jump" ? (g.player.onGround ? "PAA!" : "PAA-PAA!") : type === "slash" ? "KAA!" : "TA-TA!", type);
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, []);

  /* ---------- main loop ---------- */

  useEffect(() => {
    let raf = 0, last = 0, acc = 0, hudT = 0;
    const loop = (ts: number) => {
      const c = canvasRef.current, ctx = c?.getContext("2d");
      const g = gameRef.current, r = rendererRef.current, det = detRef.current;
      const dt = last ? Math.min(0.1, (ts - last) / 1000) : 0;
      last = ts;
      if (screenRef.current === "playing") {
        acc += dt;
        while (acc >= 1 / 120) { g.step(1 / 120); acc -= 1 / 120; }
        if (g.events.length) {
          for (const e of g.events) {
            const dur = sfxRef.current.play(e.type);
            if (dur > 0) det?.suppress(dur + 0.06, 10);
          }
          r.events(g.events);
          g.events.length = 0;
        }
        if (g.state !== "playing") finish(g);
        hudT += dt;
        if (hudT > 0.15) {
          hudT = 0;
          setHud((h) => (h.hearts !== g.hearts || h.seeds !== g.seedsTaken ? { hearts: g.hearts, seeds: g.seedsTaken, total: g.seeds.length } : h));
          const hn = g.waitHint() ?? g.nearbyHint()?.text ?? null;
          setHint((v) => (v === hn ? v : hn));
        }
        if (timeRef.current) timeRef.current.textContent = fmtTime(g.time);
        if (progRef.current) progRef.current.style.width = `${(g.progress * 100).toFixed(1)}%`;
      } else acc = 0;

      if (meterRef.current) {
        const lv = det ? Math.max(0, Math.min(1, (det.level - det.noiseFloor) / 40)) : 0;
        meterRef.current.style.width = `${(lv * 100).toFixed(0)}%`;
        meterRef.current.classList.toggle("on", !!det?.active);
      }

      if (c && ctx) {
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        const w = c.clientWidth, h = c.clientHeight;
        if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); }
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        r.draw(ctx, w, h, g, ts);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [finish]);

  // tidy up
  useEffect(() => () => {
    closeVoiceMic(micRef.current);
    micRef.current = null;
    detRef.current = null;
    sfxRef.current.close();
  }, []);

  const set = (p: Partial<Settings>) => setSettings((s) => ({ ...s, ...p }));
  const best = loadBest(settings.difficulty);

  /* ---------- UI ---------- */

  const legend = (
    <div className="vh-legend">
      <div className="vh-cmd jump"><b>“paa”</b><span>Jump</span></div>
      <div className="vh-cmd jump"><b>“paa-paa”</b><span>Double jump</span></div>
      <div className="vh-cmd slash"><b>“kaa”</b><span>Slash</span></div>
      <div className="vh-cmd dash"><b>“ta-ta-ta-ta”</b><span>Dash</span></div>
    </div>
  );

  return (
    <div className="vh">
      <div className="vh-top">
        <h1 className="vh-title">Voice Hop</h1>
        <div className="vh-mic" title="Microphone level">
          <span className={`vh-mic-dot${micOn ? " on" : ""}`} />
          <div className="vh-meter"><div ref={meterRef} /></div>
        </div>
      </div>

      <div className="vh-stage">
        <canvas ref={canvasRef} className="vh-canvas" aria-label="A side-scrolling meadow where Pip the leaf knight runs, jumps and slashes" />

        {(screen === "playing" || screen === "paused") && (
          <div className="vh-hud">
            <div className="vh-pill">{Array.from({ length: 3 }, (_, i) => <span key={i} className={`vh-heart${i < hud.hearts ? " full" : ""}`}>♥</span>)}</div>
            <div className="vh-pill"><span className="vh-seed" /> {hud.seeds}/{hud.total}</div>
            <div className="vh-pill"><span ref={timeRef}>0:00</span></div>
            <button className="vh-pill vh-pause" onClick={() => go(screen === "playing" ? "paused" : "playing")}>{screen === "playing" ? "Pause" : "Resume"}</button>
          </div>
        )}
        {screen === "playing" && hint && <div className="vh-hint" aria-live="polite">{hint}</div>}
        {screen === "playing" && heard && <div key={heard.n} className={`vh-heard ${heard.kind}`}>Heard: {heard.text}</div>}

        {screen === "menu" && (
          <div className="vh-overlay">
            <div className="vh-card">
              <p className="vh-lead">Help Pip the leaf knight reach the Sky Gate using only your voice.</p>
              {legend}
              <div className="vh-row">
                {DIFFICULTIES.map((d) => (
                  <button key={d.id} className={`vh-choice${settings.difficulty === d.id ? " on" : ""}`} onClick={() => set({ difficulty: d.id })}>
                    <b>{d.name}</b><span>{d.note}</span>
                  </button>
                ))}
              </div>
              <div className="vh-actions">
                <button className="vh-btn" onClick={startGame}>Play</button>
                <button className="vh-btn ghost" onClick={startCalibration}>{model ? "Re-teach Pip my voice" : "Teach Pip my voice (recommended)"}</button>
              </div>
              <div className="vh-options">
                <label><input type="checkbox" checked={settings.sound} onChange={(e) => set({ sound: e.target.checked })} /> Sound effects</label>
                <label>Mic sensitivity
                  <input type="range" min={6} max={24} step={1} value={30 - settings.sensitivity} onChange={(e) => set({ sensitivity: 30 - Number(e.target.value) })} />
                </label>
                {model && <button className="vh-link" onClick={forgetVoice}>Forget my voice</button>}
              </div>
              {best && <p className="vh-note">Best on {settings.difficulty}: {best.seeds} seeds in {fmtTime(best.time)}</p>}
              <p className="vh-note">Keyboard: Space jump · X slash · Shift dash · Esc pause. Headphones help Pip hear you clearly.</p>
              {micError && <p className="vh-error">{micError}</p>}
            </div>
          </div>
        )}

        {screen === "calibrate" && (
          <div className="vh-overlay">
            <div className="vh-card">
              {cal.stage === "quiet" && (<><h2>Stay quiet for a moment</h2><p className="vh-lead">Pip is listening to the room.</p></>)}
              {(cal.stage === "pa" || cal.stage === "ka" || cal.stage === "ta") && (
                <>
                  <h2>Say “{PHONEME_SAY[cal.stage]}” {CAL_N} times</h2>
                  <p className="vh-lead">One at a time, with a short pause between each, in your normal game voice.</p>
                  <div className="vh-dots">
                    {Array.from({ length: CAL_N }, (_, i) => <span key={i} className={i < cal.counts[cal.stage as Phoneme] ? "on" : ""} />)}
                  </div>
                </>
              )}
              {cal.stage === "test" && (
                <>
                  <h2>{model ? "Pip knows your voice" : "Let’s try that again"}</h2>
                  {cal.accuracy !== null && <p className="vh-lead">Pip recognised {Math.round(cal.accuracy * 100)}% of your practice sounds.{cal.accuracy < 0.8 ? " Try saying the sounds more clearly and teach again." : ""}</p>}
                  <p className="vh-lead">Test it: say paa, kaa or ta.</p>
                  <div className={`vh-test ${cal.last ?? ""}`}>{cal.last ? `${PHONEME_SAY[cal.last]} → ${cal.last === "pa" ? "jump" : cal.last === "ka" ? "slash" : "dash"}` : "…"}</div>
                </>
              )}
              <div className="vh-actions">
                {cal.stage === "test" ? (
                  <>
                    <button className="vh-btn" onClick={startGame}>Play</button>
                    <button className="vh-btn ghost" onClick={startCalibration}>Teach again</button>
                  </>
                ) : null}
                <button className="vh-link" onClick={() => go("menu")}>Back</button>
              </div>
            </div>
          </div>
        )}

        {screen === "paused" && (
          <div className="vh-overlay">
            <div className="vh-card small">
              <h2>Paused</h2>
              {legend}
              <div className="vh-actions">
                <button className="vh-btn" onClick={() => go("playing")}>Resume</button>
                <button className="vh-btn ghost" onClick={() => go("menu")}>Main menu</button>
              </div>
            </div>
          </div>
        )}

        {(screen === "won" || screen === "over") && result && (
          <div className="vh-overlay">
            <div className="vh-card small">
              <h2>{screen === "won" ? "You reached the Sky Gate!" : "Out of hearts"}</h2>
              <p className="vh-lead">
                {screen === "won" ? `Time ${fmtTime(result.time)} · ${result.seeds} of ${result.total} glow seeds${result.best ? " · New best!" : ""}` : "Pip will be ready to try again. Gentle mode never runs out of hearts."}
              </p>
              <div className="vh-stats">
                <span>Jumps <b>{result.counts.jump}</b></span>
                <span>Slashes <b>{result.counts.slash}</b></span>
                <span>Dashes <b>{result.counts.dash}</b></span>
                <span>Falls <b>{result.falls}</b></span>
              </div>
              <div className="vh-actions">
                <button className="vh-btn" onClick={startGame}>Play again</button>
                <button className="vh-btn ghost" onClick={() => go("menu")}>Main menu</button>
              </div>
            </div>
          </div>
        )}
      </div>

      {(screen === "playing" || screen === "paused") && (
        <div className="vh-track"><div ref={progRef} className="vh-fill" /><span className="vh-goal">Sky Gate</span></div>
      )}
      {(screen === "playing" || screen === "paused") && legend}
    </div>
  );
}
