// Canvas drawing for "Voice Hop": parallax meadow, tiles, Pip, enemies and effects.
// Pure drawing: it reads the Game state and never changes it.

import type { Game, GameEvent } from "./engine";
import type { CommandType } from "./voice";

type Ctx = CanvasRenderingContext2D;

interface Particle {
  x: number; y: number; vx: number; vy: number; g: number;
  life: number; max: number; size: number; color: string;
  kind: "dot" | "chunk" | "spark" | "ring" | "text";
  text?: string; rot?: number; vr?: number;
}

interface Callout { text: string; kind: CommandType | "info"; t: number }

const COMMAND_COLOR: Record<CommandType | "info", string> = {
  jump: "#2E9E5B", slash: "#D1495B", dash: "#2B7BD6", dashMore: "#2B7BD6", info: "#5B4B8A",
};

const hash = (x: number, y: number) => {
  let h = (x * 374761393 + y * 668265263) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};

export function createRenderer() {
  let parts: Particle[] = [];
  let callouts: Callout[] = [];
  let cam = 0;
  let last = 0;
  let trail: { x: number; y: number; a: number }[] = [];
  let shake = 0;

  const add = (p: Partial<Particle> & { x: number; y: number }) =>
    parts.push({ vx: 0, vy: 0, g: 0, life: 0, max: 0.6, size: 0.08, color: "#fff", kind: "dot", ...p });

  function burst(x: number, y: number, n: number, colors: string[], speed: number, kind: Particle["kind"] = "dot", g = 6, size = 0.08) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = speed * (0.4 + Math.random() * 0.6);
      add({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - speed * 0.3, g, max: 0.45 + Math.random() * 0.4, size: size * (0.6 + Math.random() * 0.8), color: colors[i % colors.length], kind, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 12 });
    }
  }

  function events(evts: GameEvent[]) {
    for (const e of evts) {
      switch (e.type) {
        case "jump": burst(e.x, e.y, 8, ["#EADBC8", "#D8C3A5"], 2.5, "dot", 4, 0.09); break;
        case "double": add({ x: e.x, y: e.y - 0.2, kind: "ring", max: 0.35, size: 0.2, color: "#9BE8C8" }); burst(e.x, e.y, 10, ["#B6F2DA", "#FFFFFF"], 3, "spark", 2, 0.07); break;
        case "slash": burst(e.x + 0.7, e.y, 6, ["#FFFFFF", "#FFE9A8"], 4, "spark", 0, 0.06); break;
        case "dash": for (let i = 0; i < 6; i++) add({ x: e.x - Math.random(), y: e.y + (Math.random() - 0.5) * 0.8, vx: -6, kind: "spark", max: 0.3, size: 0.05, color: "#BFE1FF" }); break;
        case "stomp": burst(e.x, e.y, 10, ["#8CE07A", "#FFFFFF"], 3.5, "dot", 5, 0.09); shake = 0.15; break;
        case "kill": burst(e.x, e.y, 14, ["#B98CF2", "#8CE07A", "#FFFFFF"], 4.5, "dot", 6, 0.1); add({ x: e.x, y: e.y, kind: "ring", max: 0.3, size: 0.3, color: "#FFFFFF" }); break;
        case "break": burst(e.x, e.y, 12, ["#B07A45", "#8A5A2B", "#D9A86C"], 5, "chunk", 14, 0.16); shake = 0.12; break;
        case "seed": burst(e.x, e.y, 8, ["#FFE27A", "#FFF6C8"], 2.5, "spark", 0, 0.07); add({ x: e.x, y: e.y - 0.3, vy: -1.4, kind: "text", text: "+1", max: 0.8, color: "#B8860B", size: 0.42 }); break;
        case "hurt": burst(e.x, e.y, 10, ["#FF6B6B", "#FFD1D1"], 4, "spark", 3, 0.08); shake = 0.25; break;
        case "fall": shake = 0.3; break;
        case "checkpoint": for (let i = 0; i < 3; i++) add({ x: e.x, y: e.y + 0.2, kind: "ring", max: 0.6 + i * 0.2, size: 0.3, color: "#FFD27A" }); callouts.push({ text: "Checkpoint!", kind: "info", t: 0 }); break;
        case "crumble": burst(e.x, e.y, 4, ["#A89F91", "#7C7366"], 1.5, "chunk", 8, 0.08); break;
        case "win": burst(e.x, e.y - 1, 60, ["#FF6B6B", "#FFD93D", "#6BCB77", "#4D96FF", "#C77DFF"], 8, "chunk", 6, 0.14); break;
      }
    }
  }

  function say(text: string, kind: CommandType) {
    callouts.push({ text, kind, t: 0 });
    if (callouts.length > 3) callouts.shift();
  }

  function reset() { parts = []; callouts = []; trail = []; cam = 0; shake = 0; }

  /* ---------- background ---------- */

  function hills(ctx: Ctx, w: number, h: number, base: number, amp: number, f: number, off: number, color: string) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = 0; x <= w + 10; x += 10) {
      const u = (x + off) * f;
      ctx.lineTo(x, base - amp * (0.6 + 0.25 * Math.sin(u) + 0.15 * Math.sin(u * 2.3 + 1.3)));
    }
    ctx.lineTo(w, h);
    ctx.closePath();
    ctx.fill();
  }

  function cloud(ctx: Ctx, x: number, y: number, s: number) {
    ctx.beginPath();
    [[0, 0, 22], [24, -12, 26], [52, -4, 22], [74, 4, 16], [30, 8, 22], [-18, 6, 14]].forEach(([dx, dy, r]) => {
      ctx.moveTo(x + dx * s + r * s, y + dy * s);
      ctx.arc(x + dx * s, y + dy * s, r * s, 0, Math.PI * 2);
    });
    ctx.fill();
  }

  function background(ctx: Ctx, w: number, h: number, T: number, now: number) {
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, "#7CC6F2");
    sky.addColorStop(0.6, "#BFE6F7");
    sky.addColorStop(1, "#FCEBCB");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);
    // sun
    const sx = w * 0.82, sy = h * 0.2;
    const sg = ctx.createRadialGradient(sx, sy, 0, sx, sy, T * 2.6);
    sg.addColorStop(0, "rgba(255,246,200,1)"); sg.addColorStop(0.35, "rgba(255,236,170,.9)"); sg.addColorStop(1, "rgba(255,236,170,0)");
    ctx.fillStyle = sg;
    ctx.beginPath(); ctx.arc(sx, sy, T * 2.6, 0, Math.PI * 2); ctx.fill();
    // clouds
    ctx.fillStyle = "rgba(255,255,255,.85)";
    for (let i = 0; i < 6; i++) {
      const span = w + 300;
      const x = ((i * 397 - cam * T * 0.08 - now * 0.006 * (8 + i)) % span + span) % span - 150;
      cloud(ctx, x, h * (0.1 + 0.07 * (i % 3)), T / 48 * (0.8 + 0.2 * (i % 2)));
    }
    hills(ctx, w, h, h * 0.62, T * 3.2, 0.006, cam * T * 0.15, "#A9B8E0");
    hills(ctx, w, h, h * 0.72, T * 2.2, 0.011, cam * T * 0.3 + 400, "#8FCB9B");
    hills(ctx, w, h, h * 0.8, T * 1.4, 0.02, cam * T * 0.5 + 900, "#6DB57F");
  }

  /* ---------- tiles ---------- */

  function ground(ctx: Ctx, g: Game, x: number, y: number, X: number, Y: number, T: number) {
    const topOpen = g.tile(x, y - 1) !== "#";
    ctx.fillStyle = "#9B6B43";
    ctx.fillRect(X, Y, T + 0.5, T + 0.5);
    // pebbles
    ctx.fillStyle = "#83572F";
    for (let i = 0; i < 3; i++) {
      const r = hash(x * 3 + i, y);
      ctx.beginPath(); ctx.ellipse(X + T * (0.15 + 0.7 * r), Y + T * (0.3 + 0.55 * hash(y, x + i)), T * 0.07, T * 0.05, 0, 0, Math.PI * 2); ctx.fill();
    }
    if (topOpen) {
      ctx.fillStyle = "#5DBB63";
      ctx.fillRect(X, Y, T + 0.5, T * 0.28);
      ctx.fillStyle = "#4AA352";
      ctx.fillRect(X, Y + T * 0.24, T + 0.5, T * 0.07);
      // grass tufts
      ctx.fillStyle = "#71CF73";
      for (let i = 0; i < 4; i++) {
        const gx = X + T * (0.1 + 0.25 * i + 0.05 * hash(x, i));
        ctx.beginPath(); ctx.moveTo(gx, Y + 2); ctx.lineTo(gx + T * 0.05, Y - T * 0.12); ctx.lineTo(gx + T * 0.1, Y + 2); ctx.fill();
      }
      if (hash(x, y + 7) > 0.8) { // a flower
        ctx.fillStyle = hash(x, 3) > 0.5 ? "#FF8FAB" : "#FFD166";
        ctx.beginPath(); ctx.arc(X + T * 0.5, Y - T * 0.08, T * 0.06, 0, Math.PI * 2); ctx.fill();
      }
    }
  }

  function rock(ctx: Ctx, g: Game, x: number, y: number, X: number, Y: number, T: number) {
    // tiles above ground level are stone blocks
    ctx.fillStyle = "#A39FB0";
    ctx.fillRect(X, Y, T + 0.5, T + 0.5);
    ctx.strokeStyle = "#7E7A8C";
    ctx.lineWidth = Math.max(1, T * 0.04);
    ctx.strokeRect(X + 1, Y + 1, T - 2, T - 2);
    ctx.fillStyle = "#B9B5C6";
    ctx.fillRect(X + T * 0.12, Y + T * 0.12, T * 0.35, T * 0.12);
    if (g.tile(x, y - 1) !== "#") {
      ctx.fillStyle = "#5DBB63";
      ctx.fillRect(X, Y, T + 0.5, T * 0.2);
    }
  }

  function crate(ctx: Ctx, X: number, Y: number, T: number) {
    const m = T * 0.06;
    ctx.fillStyle = "#C68A4E"; ctx.fillRect(X + m, Y + m, T - 2 * m, T - 2 * m);
    ctx.strokeStyle = "#7A4A22"; ctx.lineWidth = T * 0.08;
    ctx.strokeRect(X + m * 1.5, Y + m * 1.5, T - 3 * m, T - 3 * m);
    ctx.beginPath(); ctx.moveTo(X + m * 2, Y + m * 2); ctx.lineTo(X + T - m * 2, Y + T - m * 2);
    ctx.moveTo(X + T - m * 2, Y + m * 2); ctx.lineTo(X + m * 2, Y + T - m * 2); ctx.stroke();
  }

  function plank(ctx: Ctx, X: number, Y: number, T: number) {
    ctx.fillStyle = "#B58A5A"; ctx.fillRect(X, Y, T + 0.5, T * 0.3);
    ctx.fillStyle = "#8C6239"; ctx.fillRect(X, Y + T * 0.24, T + 0.5, T * 0.08);
    ctx.fillStyle = "#6E4A2A"; ctx.fillRect(X + T * 0.1, Y + T * 0.1, T * 0.06, T * 0.06); ctx.fillRect(X + T * 0.84, Y + T * 0.1, T * 0.06, T * 0.06);
  }

  function bridge(ctx: Ctx, X: number, Y: number, T: number, t: number | undefined, delay: number) {
    let dy = 0, dx = 0, a = 1;
    if (t !== undefined) {
      if (t < delay) dx = Math.sin(t * 80) * T * 0.03;
      else { const f = t - delay; dy = 0.5 * 30 * f * f * T; a = Math.max(0, 1 - f * 1.6); }
    }
    if (a <= 0) return;
    ctx.globalAlpha = a;
    ctx.fillStyle = "#B3AA9C"; ctx.fillRect(X + dx + 1, Y + dy, T - 2, T * 0.34);
    ctx.fillStyle = "#8D8476"; ctx.fillRect(X + dx + 1, Y + dy + T * 0.28, T - 2, T * 0.08);
    ctx.strokeStyle = "#6F675B"; ctx.lineWidth = Math.max(1, T * 0.03);
    ctx.beginPath(); ctx.moveTo(X + dx + T * 0.3, Y + dy); ctx.lineTo(X + dx + T * 0.45, Y + dy + T * 0.18); ctx.lineTo(X + dx + T * 0.38, Y + dy + T * 0.34); ctx.stroke();
    // rope
    ctx.strokeStyle = "#7A5C3A"; ctx.beginPath(); ctx.moveTo(X + dx, Y + dy - T * 0.25); ctx.lineTo(X + dx + T, Y + dy - T * 0.25); ctx.stroke();
    ctx.globalAlpha = 1;
  }

  function thorns(ctx: Ctx, X: number, Y: number, T: number) {
    ctx.fillStyle = "#6B2E6E";
    ctx.beginPath(); ctx.ellipse(X + T * 0.5, Y + T * 0.92, T * 0.52, T * 0.22, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#9B3F9E";
    for (let i = 0; i < 5; i++) {
      const bx = X + T * (0.08 + i * 0.21);
      ctx.beginPath(); ctx.moveTo(bx - T * 0.08, Y + T * 0.95); ctx.lineTo(bx, Y + T * (0.42 + 0.1 * (i % 2))); ctx.lineTo(bx + T * 0.08, Y + T * 0.95); ctx.fill();
    }
  }

  /* ---------- props ---------- */

  function seed(ctx: Ctx, X: number, Y: number, T: number, now: number, i: number) {
    const bob = Math.sin(now * 0.004 + i) * T * 0.08;
    const gl = ctx.createRadialGradient(X, Y + bob, 0, X, Y + bob, T * 0.45);
    gl.addColorStop(0, "rgba(255,230,120,.75)"); gl.addColorStop(1, "rgba(255,230,120,0)");
    ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(X, Y + bob, T * 0.45, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#F5B400";
    ctx.beginPath();
    ctx.moveTo(X, Y + bob - T * 0.22);
    ctx.quadraticCurveTo(X + T * 0.2, Y + bob, X, Y + bob + T * 0.18);
    ctx.quadraticCurveTo(X - T * 0.2, Y + bob, X, Y + bob - T * 0.22);
    ctx.fill();
    ctx.fillStyle = "#FFF3B0"; ctx.beginPath(); ctx.arc(X - T * 0.04, Y + bob - T * 0.04, T * 0.04, 0, Math.PI * 2); ctx.fill();
  }

  function sign(ctx: Ctx, X: number, Y: number, T: number, text: string) {
    ctx.fillStyle = "#7A5230"; ctx.fillRect(X + T * 0.45, Y + T * 0.2, T * 0.1, T * 0.8);
    ctx.font = `700 ${Math.round(T * 0.26)}px Verdana, sans-serif`;
    const tw = ctx.measureText(text).width + T * 0.3;
    const bx = X + T * 0.5 - tw / 2, by = Y - T * 0.25;
    ctx.fillStyle = "#D9A86C"; ctx.fillRect(bx, by, tw, T * 0.5);
    ctx.strokeStyle = "#7A5230"; ctx.lineWidth = T * 0.05; ctx.strokeRect(bx, by, tw, T * 0.5);
    ctx.fillStyle = "#4A2E16"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(text, X + T * 0.5, by + T * 0.26);
  }

  function lantern(ctx: Ctx, X: number, Y: number, T: number, lit: boolean, now: number) {
    ctx.fillStyle = "#4E4A5C"; ctx.fillRect(X + T * 0.46, Y - T * 0.6, T * 0.08, T * 1.6);
    ctx.fillRect(X + T * 0.46, Y - T * 0.6, T * 0.32, T * 0.06);
    const lx = X + T * 0.74, ly = Y - T * 0.32;
    if (lit) {
      const r = T * (0.9 + 0.08 * Math.sin(now * 0.008));
      const gl = ctx.createRadialGradient(lx, ly, 0, lx, ly, r);
      gl.addColorStop(0, "rgba(255,200,90,.8)"); gl.addColorStop(1, "rgba(255,200,90,0)");
      ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(lx, ly, r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = lit ? "#FFD27A" : "#C9C3D6";
    ctx.fillRect(lx - T * 0.13, ly - T * 0.18, T * 0.26, T * 0.34);
    ctx.strokeStyle = "#4E4A5C"; ctx.lineWidth = T * 0.04; ctx.strokeRect(lx - T * 0.13, ly - T * 0.18, T * 0.26, T * 0.34);
  }

  function goal(ctx: Ctx, X: number, Y: number, T: number, now: number) {
    const cx = X + T * 0.5, base = Y + T;
    ctx.fillStyle = "#8E8A99";
    ctx.fillRect(cx - T * 1.1, base - T * 3.2, T * 0.45, T * 3.2);
    ctx.fillRect(cx + T * 0.65, base - T * 3.2, T * 0.45, T * 3.2);
    ctx.beginPath(); ctx.arc(cx, base - T * 3.2, T * 1.1, Math.PI, 0); ctx.lineWidth = T * 0.45; ctx.strokeStyle = "#8E8A99"; ctx.stroke();
    const gl = ctx.createRadialGradient(cx, base - T * 1.8, 0, cx, base - T * 1.8, T * 1.6);
    gl.addColorStop(0, "rgba(255,255,255,.95)"); gl.addColorStop(0.5, "rgba(190,240,255,.7)"); gl.addColorStop(1, "rgba(160,120,255,.15)");
    ctx.fillStyle = gl;
    ctx.beginPath(); ctx.moveTo(cx - T * 0.65, base); ctx.lineTo(cx - T * 0.65, base - T * 3.2); ctx.arc(cx, base - T * 3.2, T * 0.65, Math.PI, 0); ctx.lineTo(cx + T * 0.65, base); ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,.7)"; ctx.lineWidth = T * 0.05;
    for (let i = 0; i < 3; i++) {
      const a = now * 0.002 + i * 2.1;
      ctx.beginPath(); ctx.arc(cx, base - T * 1.9, T * (0.25 + 0.15 * i), a, a + 2.2); ctx.stroke();
    }
    ctx.fillStyle = "#FFD166";
    ctx.beginPath(); ctx.arc(cx, base - T * 4.35, T * 0.2, 0, Math.PI * 2); ctx.fill();
  }

  /* ---------- characters ---------- */

  function blob(ctx: Ctx, X: number, Y: number, T: number, vy: number, t: number, alive: boolean, deadT: number) {
    if (!alive && deadT > 0.25) return;
    const squash = alive ? 1 + Math.max(-0.2, Math.min(0.2, -vy * 0.04)) + Math.sin(t * 6) * 0.03 : 1 - deadT * 3;
    const w = T * 0.85 / squash, h = T * 0.7 * squash;
    const cx = X + T * 0.425, by = Y + T * 0.7;
    ctx.globalAlpha = alive ? 1 : Math.max(0, 1 - deadT * 4);
    ctx.fillStyle = "#6BCB77";
    ctx.beginPath(); ctx.moveTo(cx - w / 2, by); ctx.quadraticCurveTo(cx - w / 2, by - h * 1.25, cx, by - h); ctx.quadraticCurveTo(cx + w / 2, by - h * 1.25, cx + w / 2, by); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,.45)"; ctx.beginPath(); ctx.ellipse(cx - w * 0.18, by - h * 0.7, w * 0.1, h * 0.12, -0.5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#1F2A44";
    ctx.beginPath(); ctx.arc(cx - w * 0.15, by - h * 0.45, T * 0.06, 0, Math.PI * 2); ctx.arc(cx + w * 0.12, by - h * 0.45, T * 0.06, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1;
  }

  function beetle(ctx: Ctx, X: number, Y: number, T: number, vx: number, t: number, alive: boolean, deadT: number) {
    if (!alive && deadT > 0.4) return;
    const cx = X + T * 0.45, by = Y + T * 0.62;
    ctx.save();
    ctx.translate(cx, by);
    if (!alive) { ctx.rotate(Math.PI * Math.min(1, deadT * 5)); ctx.globalAlpha = Math.max(0, 1 - deadT * 2.5); }
    if (vx > 0) ctx.scale(-1, 1);
    ctx.strokeStyle = "#2B2140"; ctx.lineWidth = T * 0.05;
    for (let i = 0; i < 3; i++) {
      const lx = -T * 0.25 + i * T * 0.22, k = Math.sin(t * 14 + i * 2) * T * 0.05;
      ctx.beginPath(); ctx.moveTo(lx, -T * 0.08); ctx.lineTo(lx + k, 0); ctx.stroke();
    }
    ctx.fillStyle = "#5B3E8C";
    ctx.beginPath(); ctx.ellipse(0, -T * 0.22, T * 0.42, T * 0.26, 0, Math.PI, 0); ctx.fill();
    ctx.fillStyle = "#E9E3F5";
    for (let i = -2; i <= 2; i++) {
      const sx = i * T * 0.15;
      ctx.beginPath(); ctx.moveTo(sx - T * 0.06, -T * 0.38 + Math.abs(i) * T * 0.05); ctx.lineTo(sx, -T * 0.58 + Math.abs(i) * T * 0.07); ctx.lineTo(sx + T * 0.06, -T * 0.38 + Math.abs(i) * T * 0.05); ctx.fill();
    }
    ctx.fillStyle = "#3D2A60"; ctx.beginPath(); ctx.arc(-T * 0.42, -T * 0.14, T * 0.13, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#FFDE59"; ctx.beginPath(); ctx.arc(-T * 0.46, -T * 0.17, T * 0.04, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ctx.globalAlpha = 1;
  }

  /** Pip: a round little dumpling knight with a leaf sprout, a teal scarf and a wooden sword. */
  function pip(ctx: Ctx, g: Game, X: number, Y: number, T: number, now: number) {
    const p = g.player;
    const r = T * 0.42;
    const cx = X + p.w * T / 2, bottom = Y + p.h * T;
    const air = !p.onGround;
    const stretch = air ? Math.max(-0.15, Math.min(0.18, -p.vy * 0.015)) : 0;
    const sx = 1 - stretch * 0.6, sy = 1 + stretch;
    const bob = p.onGround && p.vx > 0 ? Math.abs(Math.sin(p.runPhase * Math.PI)) * T * 0.05 : 0;
    const cy = bottom - r * sy - T * 0.1 - bob;
    if (p.invuln > 0 && Math.floor(now / 90) % 2 === 0) ctx.globalAlpha = 0.45;

    // scarf tail flapping behind
    const wave = Math.sin(now * 0.02) * T * 0.06;
    ctx.fillStyle = "#1FA39A";
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.5, cy + r * 0.35);
    ctx.quadraticCurveTo(cx - r * 1.3, cy + r * 0.2 + wave, cx - r * 1.75 - (p.dashT > 0 ? r * 0.6 : 0), cy + r * 0.45 + wave);
    ctx.quadraticCurveTo(cx - r * 1.2, cy + r * 0.62 - wave, cx - r * 0.4, cy + r * 0.62);
    ctx.fill();

    // feet
    ctx.fillStyle = "#7A4E2D";
    const step = p.onGround ? Math.sin(p.runPhase * Math.PI) * T * 0.1 : 0;
    ctx.beginPath(); ctx.ellipse(cx - r * 0.35 + step, bottom - T * 0.06, T * 0.12, T * 0.07, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx + r * 0.35 - step, bottom - T * 0.06, T * 0.12, T * 0.07, 0, 0, Math.PI * 2); ctx.fill();

    // body
    const bg = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.4, r * 0.2, cx, cy, r * 1.1);
    bg.addColorStop(0, "#FFF4DE"); bg.addColorStop(1, "#F4C98E");
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, cy, r * sx, r * sy, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "rgba(122,78,45,.35)"; ctx.lineWidth = Math.max(1, T * 0.03); ctx.stroke();

    // scarf band
    ctx.fillStyle = "#1FA39A";
    ctx.beginPath(); ctx.ellipse(cx, cy + r * 0.45 * sy, r * 0.92 * sx, r * 0.2, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#57C7BD"; ctx.fillRect(cx - r * 0.1, cy + r * 0.38 * sy, r * 0.5, r * 0.08);

    // leaf sprout
    ctx.strokeStyle = "#3E8E41"; ctx.lineWidth = T * 0.04;
    ctx.beginPath(); ctx.moveTo(cx, cy - r * sy); ctx.quadraticCurveTo(cx + r * 0.05, cy - r * sy - T * 0.15, cx + r * 0.1, cy - r * sy - T * 0.2); ctx.stroke();
    ctx.fillStyle = "#6BCB77";
    ctx.save(); ctx.translate(cx + r * 0.12, cy - r * sy - T * 0.2); ctx.rotate(-0.6 + Math.sin(now * 0.01) * 0.15);
    ctx.beginPath(); ctx.ellipse(T * 0.11, 0, T * 0.13, T * 0.06, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();

    // face
    const blink = Math.floor(now / 2600) % 7 === 0 && now % 2600 < 140;
    ctx.fillStyle = "#2B2140";
    if (blink || p.invuln > 1.2) {
      ctx.fillRect(cx + r * 0.05, cy - r * 0.15, r * 0.2, r * 0.06); ctx.fillRect(cx + r * 0.45, cy - r * 0.15, r * 0.18, r * 0.06);
    } else {
      ctx.beginPath(); ctx.ellipse(cx + r * 0.15, cy - r * 0.12, r * 0.09, r * 0.13, 0, 0, Math.PI * 2); ctx.ellipse(cx + r * 0.55, cy - r * 0.12, r * 0.08, r * 0.12, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(cx + r * 0.18, cy - r * 0.17, r * 0.035, 0, Math.PI * 2); ctx.arc(cx + r * 0.57, cy - r * 0.17, r * 0.03, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = "rgba(255,120,140,.45)";
    ctx.beginPath(); ctx.ellipse(cx - r * 0.05, cy + r * 0.12, r * 0.13, r * 0.08, 0, 0, Math.PI * 2); ctx.ellipse(cx + r * 0.72, cy + r * 0.12, r * 0.1, r * 0.07, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#2B2140"; ctx.lineWidth = Math.max(1, T * 0.025);
    ctx.beginPath();
    if (p.slashT > 0 || p.dashT > 0) ctx.ellipse(cx + r * 0.36, cy + r * 0.12, r * 0.08, r * 0.1, 0, 0, Math.PI * 2);
    else ctx.arc(cx + r * 0.36, cy + r * 0.05, r * 0.1, 0.2, Math.PI - 0.2);
    ctx.stroke();

    // wooden sword
    const swing = p.slashT > 0 ? 1 - p.slashT / 0.3 : -1;
    const ang = swing >= 0 ? -1.9 + swing * 3.0 : -0.7 + Math.sin(p.runPhase * Math.PI) * 0.08;
    ctx.save();
    ctx.translate(cx + r * 0.75, cy + r * 0.2);
    ctx.rotate(ang);
    ctx.fillStyle = "#7A4E2D"; ctx.fillRect(-T * 0.03, -T * 0.05, T * 0.18, T * 0.1);
    ctx.fillStyle = "#A0522D"; ctx.fillRect(T * 0.13, -T * 0.1, T * 0.05, T * 0.2);
    ctx.fillStyle = "#E8C99B"; ctx.beginPath(); ctx.moveTo(T * 0.18, -T * 0.05); ctx.lineTo(T * 0.62, -T * 0.04); ctx.lineTo(T * 0.7, 0); ctx.lineTo(T * 0.62, T * 0.04); ctx.lineTo(T * 0.18, T * 0.05); ctx.fill();
    ctx.restore();
    if (swing >= 0 && swing < 0.8) {
      ctx.strokeStyle = `rgba(255,255,255,${0.85 * (1 - swing)})`;
      ctx.lineWidth = T * 0.14;
      ctx.lineCap = "round";
      ctx.beginPath(); ctx.arc(cx + r * 0.75, cy + r * 0.2, T * 1.15, -1.7, -1.7 + swing * 2.9); ctx.stroke();
      ctx.strokeStyle = `rgba(255,214,102,${0.6 * (1 - swing)})`;
      ctx.lineWidth = T * 0.06;
      ctx.beginPath(); ctx.arc(cx + r * 0.75, cy + r * 0.2, T * 1.3, -1.6, -1.6 + swing * 2.8); ctx.stroke();
      ctx.lineCap = "butt";
    }
    ctx.globalAlpha = 1;
  }

  /* ---------- main draw ---------- */

  function draw(ctx: Ctx, w: number, h: number, g: Game, now: number, debug = false) {
    const dt = last ? Math.min(0.05, (now - last) / 1000) : 0;
    last = now;
    const VIEW_ROWS = 11, TOP_ROW = 1; // the top row is always empty sky, so zoom in a little
    const T = h / VIEW_ROWS;
    const viewTiles = w / T;
    const target = Math.max(0, Math.min(g.w - viewTiles, g.player.x - viewTiles * 0.3));
    cam += (target - cam) * Math.min(1, dt * 8);
    if (Math.abs(target - cam) > 6) cam = target;
    shake = Math.max(0, shake - dt);
    const sh = shake > 0 ? (Math.random() - 0.5) * T * 0.12 * (shake / 0.3) : 0;

    background(ctx, w, h, T, now);
    ctx.save();
    ctx.translate(-cam * T + sh, sh * 0.5 - TOP_ROW * T);

    const x0 = Math.max(0, Math.floor(cam) - 1), x1 = Math.min(g.w - 1, Math.ceil(cam + viewTiles) + 1);
    // pits: a dark drop where the ground is missing
    const pitGrad = ctx.createLinearGradient(0, 10 * T, 0, 12 * T);
    pitGrad.addColorStop(0, "#3B2A3F"); pitGrad.addColorStop(1, "#150E1C");
    for (let x = x0; x <= x1; x++) {
      if (g.tile(x, 11) === "#") continue;
      ctx.fillStyle = pitGrad;
      ctx.fillRect(x * T - 0.5, 10 * T, T + 1, T * 2);
      ctx.fillStyle = "#2A1D2E";
      if (g.tile(x - 1, 11) === "#") ctx.fillRect(x * T, 10 * T + T * 0.3, T * 0.12, T * 1.7);
      if (g.tile(x + 1, 11) === "#") ctx.fillRect((x + 1) * T - T * 0.12, 10 * T + T * 0.3, T * 0.12, T * 1.7);
    }
    for (let y = 0; y < g.h; y++) {
      for (let x = x0; x <= x1; x++) {
        const c = g.tiles[y][x];
        if (c === ".") continue;
        const X = x * T, Y = y * T;
        if (c === "#") (y >= 10 ? ground : rock)(ctx, g, x, y, X, Y, T);
        else if (c === "C") crate(ctx, X, Y, T);
        else if (c === "=") plank(ctx, X, Y, T);
        else if (c === "~") bridge(ctx, X, Y, T, g.crumble.get(`${x},${y}`), 0.3);
        else if (c === "^") thorns(ctx, X, Y, T);
      }
    }
    for (const s of g.signs) if (s.x >= x0 - 2 && s.x <= x1 + 2) sign(ctx, s.x * T, s.y * T, T, ({ "1": "PAA", "2": "PAA-PAA", "3": "KAA", "4": "TA-TA-TA" } as Record<string, string>)[s.id] ?? "");
    for (const l of g.lanterns) if (l.x >= x0 - 2 && l.x <= x1 + 2) lantern(ctx, l.x * T, l.y * T, T, l.lit, now);
    if (g.goal.x >= x0 - 3 && g.goal.x <= x1 + 3) goal(ctx, g.goal.x * T, g.goal.y * T, T, now);
    g.seeds.forEach((s, i) => { if (!s.taken && s.x >= x0 - 1 && s.x <= x1 + 1) seed(ctx, s.x * T, s.y * T, T, now, i); });
    for (const e of g.enemies) {
      if (e.x < x0 - 2 || e.x > x1 + 2) continue;
      if (e.kind === "blob") blob(ctx, e.x * T, e.y * T, T, e.vy, e.t, e.alive, e.deadT);
      else beetle(ctx, e.x * T, e.y * T, T, e.vx, e.t, e.alive, e.deadT);
    }

    // dash afterimages
    const p = g.player;
    if (p.dashT > 0) trail.push({ x: p.x, y: p.y, a: 0.5 });
    trail = trail.filter((t) => (t.a -= dt * 2.2) > 0).slice(-8);
    for (const t of trail) {
      ctx.globalAlpha = t.a * 0.6;
      ctx.fillStyle = "#9CC9FF";
      ctx.beginPath(); ctx.ellipse((t.x + p.w / 2) * T, (t.y + p.h * 0.5) * T, T * 0.4, T * 0.38, 0, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    if (p.dashT > 0) {
      ctx.strokeStyle = "rgba(255,255,255,.8)"; ctx.lineWidth = T * 0.04;
      for (let i = 0; i < 4; i++) {
        const ly = (p.y + 0.15 + i * 0.22) * T, lx = (p.x - 0.3 - ((now * 0.01 + i * 0.37) % 1)) * T;
        ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(lx - T * 0.6, ly); ctx.stroke();
      }
    }

    pip(ctx, g, p.x * T, p.y * T, T, now);

    // particles
    parts = parts.filter((q) => (q.life += dt) < q.max);
    for (const q of parts) {
      q.vy += q.g * dt; q.x += q.vx * dt; q.y += q.vy * dt;
      if (q.rot !== undefined && q.vr !== undefined) q.rot += q.vr * dt;
      const a = 1 - q.life / q.max;
      ctx.globalAlpha = a;
      ctx.fillStyle = q.color; ctx.strokeStyle = q.color;
      if (q.kind === "ring") {
        ctx.lineWidth = T * 0.06;
        ctx.beginPath(); ctx.arc(q.x * T, q.y * T, T * (q.size + q.life * 2.5), 0, Math.PI * 2); ctx.stroke();
      } else if (q.kind === "chunk") {
        ctx.save(); ctx.translate(q.x * T, q.y * T); ctx.rotate(q.rot ?? 0); ctx.fillRect(-q.size * T / 2, -q.size * T / 2, q.size * T, q.size * T * 0.7); ctx.restore();
      } else if (q.kind === "spark") {
        ctx.save(); ctx.translate(q.x * T, q.y * T); ctx.rotate(Math.atan2(q.vy, q.vx));
        ctx.fillRect(-q.size * T * 2, -q.size * T / 3, q.size * T * 4, q.size * T * 0.66); ctx.restore();
      } else if (q.kind === "text") {
        ctx.font = `700 ${Math.round(T * q.size)}px Verdana, sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
        ctx.fillText(q.text ?? "", q.x * T, q.y * T);
      } else {
        ctx.beginPath(); ctx.arc(q.x * T, q.y * T, q.size * T, 0, Math.PI * 2); ctx.fill();
      }
    }
    ctx.globalAlpha = 1;

    // command callouts above Pip
    callouts = callouts.filter((c) => (c.t += dt) < 0.9);
    callouts.forEach((c, i) => {
      const k = c.t / 0.9;
      const scale = c.t < 0.12 ? 0.6 + (c.t / 0.12) * 0.5 : 1.1 - Math.min(0.1, (c.t - 0.12));
      const bx = (p.x + p.w / 2) * T, by = (p.y - 0.5 - k * 0.8 - (callouts.length - 1 - i) * 0.55) * T;
      ctx.globalAlpha = Math.min(1, (1 - k) * 2.2);
      ctx.font = `800 ${Math.round(T * 0.42 * scale)}px Verdana, sans-serif`;
      ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.lineWidth = T * 0.12; ctx.strokeStyle = "#FFFFFF"; ctx.lineJoin = "round";
      ctx.strokeText(c.text, bx, by);
      ctx.fillStyle = COMMAND_COLOR[c.kind];
      ctx.fillText(c.text, bx, by);
    });
    ctx.globalAlpha = 1;

    // Gentle mode: Pip is waiting
    if (p.waiting) {
      const bx = (p.x + p.w / 2) * T, by = (p.y - 0.75) * T + Math.sin(now * 0.006) * T * 0.06;
      ctx.fillStyle = "rgba(255,255,255,.95)";
      ctx.beginPath(); ctx.arc(bx, by, T * 0.32, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.moveTo(bx - T * 0.1, by + T * 0.25); ctx.lineTo(bx, by + T * 0.45); ctx.lineTo(bx + T * 0.08, by + T * 0.25); ctx.fill();
      ctx.fillStyle = "#5B4B8A"; ctx.font = `800 ${Math.round(T * 0.38)}px Verdana, sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText("?", bx, by + 1);
    }

    if (debug) {
      ctx.strokeStyle = "rgba(255,0,0,.6)"; ctx.lineWidth = 1;
      ctx.strokeRect(p.x * T, p.y * T, p.w * T, p.h * T);
      for (const e of g.enemies) if (e.alive) ctx.strokeRect(e.x * T, e.y * T, e.w * T, e.h * T);
      ctx.strokeStyle = "rgba(91,75,138,.7)";
      for (const m of g.markers) { ctx.beginPath(); ctx.moveTo(m.x * T, 8.5 * T); ctx.lineTo(m.x * T, 10 * T); ctx.stroke(); }
    }
    ctx.restore();
  }

  return { draw, events, say, reset };
}
