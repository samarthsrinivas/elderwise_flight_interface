// Voice commands for "Voice Hop". Everything runs on the device, in real time.
//
// We listen for short syllables and look at the first ~16 ms of each one, where the
// consonant burst is. /p/ bursts are weak and low-pitched, /k/ bursts peak in the middle
// (about 1.5-3 kHz) and /t/ bursts are bright (above about 3.5 kHz). Calibration
// ("Teach Pip your voice") learns what your own pa / ka / ta sound like.
//
//   "paa"           -> jump
//   "paa-paa"       -> jump, then jump again in the air (double jump)
//   "kaa"           -> slash
//   "ta-ta-ta-ta"   -> dash (each extra "ta" keeps the dash going)

export type Phoneme = "pa" | "ka" | "ta";
export type CommandType = "jump" | "slash" | "dash" | "dashMore";

export interface VoiceCommand {
  type: CommandType;
  phoneme: Phoneme;
  /** 1 for the first syllable of a quick run, 2 for the second, ... */
  runIndex: number;
  label: string;
  confidence: number;
  /** seconds on the audio clock */
  at: number;
  source: "voice" | "keyboard";
}

export interface Syllable {
  phoneme: Phoneme;
  confidence: number;
  features: number[];
  at: number;
}

export const PHONEMES: Phoneme[] = ["pa", "ka", "ta"];
export const FEATURE_COUNT = 6;
const BLOCK = 256; // samples per message from the audio thread (about 5 ms)

/* ---------------- maths ---------------- */

function rmsDb(b: Float32Array): number {
  let s = 0;
  for (let i = 0; i < b.length; i++) s += b[i] * b[i];
  return 20 * Math.log10(Math.sqrt(s / Math.max(1, b.length)) + 1e-12);
}

/** In-place radix-2 FFT. re/im length must be a power of two. */
function fft(re: Float64Array, im: Float64Array) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (-2 * Math.PI) / len;
    const wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1, ci = 0;
      for (let k = 0; k < len / 2; k++) {
        const a = i + k, b = a + len / 2;
        const tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
        re[b] = re[a] - tr; im[b] = im[a] - ti;
        re[a] += tr; im[a] += ti;
        const nr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = nr;
      }
    }
  }
}

/** YIN pitch detector. Returns true when the window looks voiced (a vowel). */
function isVoiced(buf: Float32Array, sr: number): boolean {
  const maxLag = Math.floor(sr / 70), minLag = Math.max(2, Math.floor(sr / 500));
  const W = buf.length - maxLag;
  if (W < 64) return false;
  const d = new Float32Array(maxLag + 2);
  for (let tau = 1; tau <= maxLag + 1; tau++) {
    let s = 0;
    for (let i = 0; i < W; i++) { const x = buf[i] - buf[i + tau]; s += x * x; }
    d[tau] = s;
  }
  let run = 0;
  for (let tau = 1; tau <= maxLag; tau++) {
    run += d[tau];
    const c = run > 0 ? (d[tau] * tau) / run : 1;
    if (tau >= minLag && c < 0.3) return true;
  }
  return false;
}

/** Spectral features of the consonant burst (see FEATURE_COUNT). */
export function burstFeatures(x: Float32Array, sr: number): number[] {
  let n = 1;
  while (n < x.length) n <<= 1;
  const re = new Float64Array(n), im = new Float64Array(n);
  for (let i = 0; i < x.length; i++) re[i] = x[i] * (0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (x.length - 1)));
  fft(re, im);
  const edges = [150, 700, 1500, 3000, 5000, Math.min(10000, sr / 2)];
  const bands = new Array(5).fill(1e-12);
  let total = 1e-12, weighted = 0;
  for (let k = 1; k < n / 2; k++) {
    const f = (k * sr) / n;
    if (f < edges[0] || f > edges[5]) continue;
    const p = re[k] * re[k] + im[k] * im[k];
    total += p;
    weighted += p * f;
    for (let b = 0; b < 5; b++) if (f >= edges[b] && f < edges[b + 1]) { bands[b] += p; break; }
  }
  const feats = bands.map((b) => Math.log10(b / total));
  feats.push(weighted / total / 1000); // spectral centroid in kHz
  return feats;
}

/* ---------------- classifier ---------------- */

export interface VoiceModel {
  version: 1;
  means: Record<Phoneme, number[]>;
  sd: number[];
  counts: Record<Phoneme, number>;
  createdAt: string;
}

/** Heuristic used before calibration: based on the burst's spectral centroid. */
function heuristic(f: number[]): { phoneme: Phoneme; confidence: number } {
  const centroid = f[5];
  const high = Math.log10(10 ** f[3] + 10 ** f[4]); // share above 3 kHz
  if (centroid > 3.2 || high > -0.35) return { phoneme: "ta", confidence: 0.5 };
  if (centroid > 1.7 && f[2] > f[0]) return { phoneme: "ka", confidence: 0.5 };
  return { phoneme: "pa", confidence: 0.5 };
}

export function classify(f: number[], model: VoiceModel | null): { phoneme: Phoneme; confidence: number } {
  if (!model) return heuristic(f);
  const dist = PHONEMES.map((p) => {
    const m = model.means[p];
    let s = 0;
    for (let i = 0; i < f.length; i++) s += ((f[i] - m[i]) / model.sd[i]) ** 2;
    return { p, s };
  }).sort((a, b) => a.s - b.s);
  const conf = dist[1].s > 0 ? 1 - dist[0].s / dist[1].s : 0;
  return { phoneme: dist[0].p, confidence: Math.max(0, Math.min(1, conf)) };
}

/** Nearest-centroid model with pooled per-feature spread. Needs 2+ samples per syllable. */
export function trainModel(samples: { phoneme: Phoneme; features: number[] }[]): VoiceModel | null {
  const by: Record<Phoneme, number[][]> = { pa: [], ka: [], ta: [] };
  samples.forEach((s) => by[s.phoneme].push(s.features));
  if (PHONEMES.some((p) => by[p].length < 2)) return null;
  const means = {} as Record<Phoneme, number[]>;
  const counts = {} as Record<Phoneme, number>;
  for (const p of PHONEMES) {
    counts[p] = by[p].length;
    means[p] = Array.from({ length: FEATURE_COUNT }, (_, i) => by[p].reduce((a, f) => a + f[i], 0) / by[p].length);
  }
  const sd = Array.from({ length: FEATURE_COUNT }, (_, i) => {
    let s = 0, n = 0;
    for (const p of PHONEMES) for (const f of by[p]) { s += (f[i] - means[p][i]) ** 2; n++; }
    return Math.max(i === 5 ? 0.15 : 0.04, Math.sqrt(s / Math.max(1, n - PHONEMES.length)));
  });
  return { version: 1, means, sd, counts, createdAt: new Date().toISOString() };
}

const MODEL_KEY = "voicehop.voiceModel.v1";
export function loadModel(): VoiceModel | null {
  try {
    const raw = localStorage.getItem(MODEL_KEY);
    const m = raw ? (JSON.parse(raw) as VoiceModel) : null;
    return m && m.version === 1 && m.sd?.length === FEATURE_COUNT ? m : null;
  } catch {
    return null;
  }
}
export function saveModel(m: VoiceModel | null) {
  try {
    if (m) localStorage.setItem(MODEL_KEY, JSON.stringify(m));
    else localStorage.removeItem(MODEL_KEY);
  } catch {
    /* storage unavailable */
  }
}

/* ---------------- syllable detector ---------------- */

export interface DetectorOptions {
  sampleRate: number;
  onSyllable: (s: Syllable) => void;
}

/**
 * Finds syllables in the microphone stream and classifies their first consonant.
 * Feed it audio with push(); it calls onSyllable about 30-90 ms after each onset.
 */
export class SyllableDetector {
  readonly sr: number;
  model: VoiceModel | null = null;
  /** dB above the room noise needed to count as speech (lower = more sensitive). */
  sensitivity = 14;
  level = -90;
  noiseFloor = -65;
  active = false;
  enabled = true;

  private onSyllable: (s: Syllable) => void;
  private ring: Float32Array;
  private total = 0;
  private hpX = 0;
  private hpY = 0;
  private hpA: number;
  private hist: number[] = [];
  private state: "idle" | "pending" | "active" = "idle";
  private trigger = 0;
  private start = 0;
  private pendingT = 0;
  private above = 0;
  private peak = -90;
  private lastOnset = -9;
  private suppressUntil = 0;
  private suppressDb = 0;
  private noiseSamples: number[] | null = null;

  constructor(opts: DetectorOptions) {
    this.sr = opts.sampleRate;
    this.onSyllable = opts.onSyllable;
    this.ring = new Float32Array(Math.ceil(this.sr * 0.6));
    const rc = 1 / (2 * Math.PI * 120);
    this.hpA = rc / (rc + 1 / this.sr);
  }

  get now() { return this.total / this.sr; }
  get threshold() { return this.noiseFloor + this.sensitivity + (this.now < this.suppressUntil ? this.suppressDb : 0); }

  /** Ignore quieter sounds for a moment, e.g. while our own sound effect plays. */
  suppress(seconds: number, db = 12) {
    this.suppressUntil = Math.max(this.suppressUntil, this.now + seconds);
    this.suppressDb = db;
  }

  /** Measure the room for a moment; call finishNoise() afterwards. */
  beginNoise() { this.noiseSamples = []; }
  finishNoise() {
    const xs = this.noiseSamples;
    this.noiseSamples = null;
    if (!xs || xs.length < 10) return;
    const s = [...xs].sort((a, b) => a - b);
    this.noiseFloor = Math.max(-85, Math.min(-35, s[Math.floor(s.length * 0.4)]));
  }

  private samples(startAbs: number, n: number): Float32Array {
    const out = new Float32Array(n), len = this.ring.length;
    const first = Math.max(startAbs, this.total - len);
    for (let i = 0; i < n; i++) {
      const a = first + i;
      out[i] = a < this.total ? this.ring[((a % len) + len) % len] : 0;
    }
    return out;
  }

  push(block: Float32Array) {
    const len = this.ring.length;
    let sq = 0;
    for (let i = 0; i < block.length; i++) {
      const y = this.hpA * (this.hpY + block[i] - this.hpX);
      this.hpX = block[i];
      this.hpY = y;
      this.ring[(this.total + i) % len] = y;
      sq += y * y;
    }
    this.total += block.length;
    const db = 20 * Math.log10(Math.sqrt(sq / block.length) + 1e-12);
    this.level = db;
    const blockSec = block.length / this.sr;
    const histMax = Math.max(4, Math.round(0.08 / blockSec));
    const recentMin = this.hist.length ? Math.min(...this.hist) : db;
    this.hist.push(db);
    if (this.hist.length > histMax) this.hist.shift();

    if (this.noiseSamples) { this.noiseSamples.push(db); return; }
    if (!this.enabled) { this.state = "idle"; this.active = false; return; }

    const t = this.now, th = this.threshold;

    if (this.state === "idle") {
      // track the room slowly so the threshold follows fans, traffic, etc.
      if (db < this.noiseFloor) this.noiseFloor += (db - this.noiseFloor) * 0.05;
      else if (db < this.noiseFloor + 5) this.noiseFloor += (db - this.noiseFloor) * 0.01;
      this.noiseFloor = Math.max(-90, Math.min(-30, this.noiseFloor));

      if (db > th && db - recentMin > 7 && t - this.lastOnset > 0.07) {
        this.state = "pending";
        this.trigger = this.total - block.length;
        // walk back to where the sound first rose out of the noise (the consonant burst)
        let k = 0;
        const quiet = this.noiseFloor + 6;
        for (let i = this.hist.length - 2; i >= 0 && k < 10; i--, k++) if (this.hist[i] < quiet) break;
        this.start = this.trigger - k * block.length;
        this.pendingT = t;
        this.above = 1;
        this.peak = db;
        this.lastOnset = t;
      }
      return;
    }

    if (this.state === "pending") {
      this.peak = Math.max(this.peak, db);
      if (db > th - 3) this.above++;
      const age = t - this.pendingT;
      if (db < th - 6 && age < 0.05) { this.state = "idle"; return; } // a click or tap
      const sustained = this.above * blockSec >= 0.08;
      let voiced = false;
      if (age >= 0.025) {
        const win = this.samples(this.total - Math.round(0.03 * this.sr), Math.round(0.03 * this.sr));
        const dec = new Float32Array(win.length >> 1);
        for (let i = 0; i < dec.length; i++) dec[i] = 0.5 * (win[2 * i] + win[2 * i + 1]);
        voiced = isVoiced(dec, this.sr / 2);
      }
      if (voiced || sustained || age > 0.16) {
        if (!voiced && !sustained) { this.state = "idle"; return; }
        const burst = this.samples(this.start - Math.round(0.002 * this.sr), Math.round(0.016 * this.sr));
        const features = burstFeatures(burst, this.sr);
        const { phoneme, confidence } = classify(features, this.model);
        this.state = "active";
        this.active = true;
        this.onSyllable({ phoneme, confidence, features, at: this.pendingT });
      }
      return;
    }

    // inside a syllable: wait for it to end (silence or the closure before the next "ta")
    this.peak = Math.max(this.peak, db);
    if (db < th - 4 || db < this.peak - 12) {
      this.state = "idle";
      this.active = false;
    }
  }
}

/* ---------------- syllables -> game commands ---------------- */

const RUN_GAP = 0.5; // syllables closer than this belong to one run ("paa-paa", "ta-ta-ta")
const FAST_GAP = 0.24; // a trill: "tatatata"

export class CommandMapper {
  private lastT = -9;
  private runIndex = 0;
  private lastType: CommandType | null = null;

  reset() { this.lastT = -9; this.runIndex = 0; this.lastType = null; }

  map(s: Syllable): VoiceCommand {
    const gap = s.at - this.lastT;
    if (gap > RUN_GAP) { this.runIndex = 0; this.lastType = null; }
    this.runIndex++;
    this.lastT = s.at;
    const fast = this.runIndex >= 2 && gap < FAST_GAP;
    const dashing = this.lastType === "dash" || this.lastType === "dashMore";

    let type: CommandType;
    if (fast && (dashing || s.phoneme === "ta" || this.runIndex >= 3)) type = dashing ? "dashMore" : "dash";
    else if (s.phoneme === "pa") type = "jump";
    else if (s.phoneme === "ka") type = "slash";
    else type = dashing ? "dashMore" : "dash";

    const label =
      type === "jump" ? (this.lastType === "jump" ? "PAA-PAA!" : "PAA!")
        : type === "slash" ? "KAA!"
          : type === "dash" ? "TA-TA!" : "TA!";
    this.lastType = type;
    return { type, phoneme: s.phoneme, runIndex: this.runIndex, label, confidence: s.confidence, at: s.at, source: "voice" };
  }
}

/* ---------------- microphone ---------------- */

export interface VoiceMic {
  ctx: AudioContext;
  stream: MediaStream;
  node: AudioNode;
}

const WORKLET = `
class VhTap extends AudioWorkletProcessor {
  constructor() { super(); this.buf = new Float32Array(${BLOCK}); this.n = 0; }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (ch) for (let i = 0; i < ch.length; i++) {
      this.buf[this.n++] = ch[i];
      if (this.n === ${BLOCK}) { this.port.postMessage(this.buf, [this.buf.buffer]); this.buf = new Float32Array(${BLOCK}); this.n = 0; }
    }
    return true;
  }
}
registerProcessor("vh-tap", VhTap);`;

export async function openVoiceMic(onBlock: (b: Float32Array) => void): Promise<VoiceMic> {
  const stream = await navigator.mediaDevices.getUserMedia({
    // echo cancellation helps ignore the game's own sounds; the rest stays off so bursts are kept
    audio: { echoCancellation: true, noiseSuppression: false, autoGainControl: false, channelCount: 1 },
    video: false,
  });
  const ctx = new AudioContext({ latencyHint: "interactive" });
  await ctx.resume();
  const src = ctx.createMediaStreamSource(stream);
  const mute = ctx.createGain();
  mute.gain.value = 0;
  let node: AudioNode;
  try {
    const url = URL.createObjectURL(new Blob([WORKLET], { type: "application/javascript" }));
    await ctx.audioWorklet.addModule(url);
    URL.revokeObjectURL(url);
    const w = new AudioWorkletNode(ctx, "vh-tap", { numberOfInputs: 1, numberOfOutputs: 1, channelCount: 1 });
    w.port.onmessage = (e: MessageEvent<Float32Array>) => onBlock(e.data);
    node = w;
  } catch {
    const sp = ctx.createScriptProcessor(512, 1, 1);
    sp.onaudioprocess = (ev) => onBlock(new Float32Array(ev.inputBuffer.getChannelData(0)));
    node = sp;
  }
  src.connect(node);
  node.connect(mute);
  mute.connect(ctx.destination);
  return { ctx, stream, node };
}

export function closeVoiceMic(m: VoiceMic | null) {
  if (!m) return;
  try {
    if (m.node instanceof AudioWorkletNode) m.node.port.onmessage = null;
    m.node.disconnect();
  } catch {
    /* already closed */
  }
  m.stream.getTracks().forEach((t) => t.stop());
  m.ctx.close().catch(() => {});
}

export { rmsDb };
