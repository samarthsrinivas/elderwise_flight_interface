// The level, drawn as text. 12 rows tall; each character is one tile.
//
//   #  ground / stone        =  wooden platform (stand on top, jump up through)
//   ~  crumbling bridge      ^  thorns
//   C  crate (slash it)      *  glow seed
//   B  jelly blob (slash or stomp)        S  spike beetle (slash or dash)
//   L  lantern checkpoint    G  goal gate     P  start
//   1-4 hint signs           w  Gentle mode waits here (Pip stops at the right edge of this tile)

export const HINTS: Record<string, { say: string; text: string }> = {
  "1": { say: "PAA", text: "Say “paa” to jump" },
  "2": { say: "PAA-PAA", text: "Say “paa-paa” to double jump" },
  "3": { say: "KAA", text: "Say “kaa” to slash" },
  "4": { say: "TA-TA-TA", text: "Say “ta-ta-ta-ta” to dash" },
};

// Each section lists rows 4-11 (rows 0-3 are open sky).
const SECTIONS: string[][] = [
  // start
  [
    "..............",
    "..............",
    "..............",
    "......*.*.*...",
    "..............",
    ".P..1.........",
    "##############",
    "##############",
  ],
  // jumping: two gaps and a thorn bush
  [
    "........................",
    "........................",
    "....*......*............",
    "...*.*....*.*.....*.....",
    "........................",
    "...w.....w.......w.^....",
    "####..####..############",
    "####..####..############",
  ],
  // double jump: a wall and a tall rock with seeds on top
  [
    "..........................",
    "..........*...............",
    ".........*.*......***.....",
    ".......##.........####....",
    ".......##.........####....",
    ".L.2...##.........####....",
    "##########################",
    "##########################",
  ],
  // slash: crates, a blob and a beetle
  [
    "..............................",
    "..............................",
    "..............................",
    ".........*.........*..........",
    ".................C............",
    "..3....C.w.B.....C...w.S......",
    "##############################",
    "##############################",
  ],
  // dash: a wide gap, then a crumbling bridge over a pit
  [
    "..................................",
    "..................................",
    ".........*.*.*....................",
    "..................*.*.*.*.........",
    "..................................",
    ".L.4...w.......w..................",
    "########....####~~~~~~~~##########",
    "########....####........##########",
  ],
  // finale: everything together
  [
    "......................................",
    "................***...................",
    "................................*.....",
    "................####...........*.*....",
    "................####..................",
    "....w...w.B..C..####.Lw.S....w........",
    "#####..#######################....####",
    "#####..#######################....####",
  ],
  // finish
  [
    "...................",
    "...................",
    "....*.*.*..........",
    "...................",
    "..=====............",
    ".L........G........",
    "###################",
    "###################",
  ],
];

export const ROWS = 12;

export function buildLevelRows(): string[] {
  const rows: string[] = Array.from({ length: ROWS }, () => "");
  for (const sec of SECTIONS) {
    const w = sec[0].length;
    sec.forEach((r, i) => {
      if (r.length !== w) throw new Error(`level row ${i + 4} has length ${r.length}, expected ${w}`);
    });
    for (let r = 0; r < 4; r++) rows[r] += ".".repeat(w);
    sec.forEach((r, i) => (rows[i + 4] += r));
  }
  return rows;
}
