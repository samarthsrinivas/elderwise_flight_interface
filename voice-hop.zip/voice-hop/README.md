# Voice Hop — a voice-controlled platformer for your Tauri app

Pip the leaf knight runs on his own. You steer him with your voice:

| Say | Pip does |
| --- | --- |
| **"paa"** | Jump |
| **"paa-paa"** | Double jump (the second "paa" while in the air) |
| **"kaa"** | Sword slash — breaks crates, defeats blobs and beetles |
| **"ta-ta-ta-ta"** | Dash — each extra "ta" keeps it going |

Keyboard also works: **Space** jump, **X** slash, **Shift** dash, **Esc** pause.

Everything runs on the device. Nothing is recorded, saved or sent anywhere.

## Install

Copy these files into your Tauri project (for example `D:\elderverse`):

    src/games/voicehop/VoiceHopGame.tsx   the game screen (React)
    src/games/voicehop/engine.ts          physics, enemies, hearts, checkpoints
    src/games/voicehop/level.ts           the level, drawn as text
    src/games/voicehop/render.ts          canvas drawing
    src/games/voicehop/voice.ts           microphone, syllable detection, calibration
    src/games/voicehop/sfx.ts             synthesized sound effects
    src/games/voicehop/voicehop.css       styles
    src/App.tsx                           adds tabs: Take off | Voice Hop  (replaces yours)
    src/app.css                           page background + tab styles (replaces yours)

Then:

    npm run tauri dev

No Rust changes and no new packages are needed.

**Already have Take off installed?** `App.tsx` shows both games as tabs. If you do not
have `src/games/takeoff/`, open `src/App.tsx` and delete the three lines that mention
takeoff, plus the Take off tab button.

## First run

1. Press **"Teach Pip my voice"** on the menu and say each sound 4 times when asked.
   This teaches the game your voice and microphone; it is saved for next time.
2. Pick a mode and press **Play**.

| Mode | What it does |
| --- | --- |
| **Gentle** | Pip stops at each obstacle and waits, with a hint on screen. No game over. |
| **Normal** | Pip keeps running. 3 hearts. |
| **Fast** | Quicker running for confident players. |

## How the voice detection works

The first ~16 ms of a syllable is the consonant burst, and the three sounds differ there:
**p** is weak and low, **k** peaks in the middle (about 1.5–3 kHz) and **t** is bright
(above 3.5 kHz). The game measures the energy in five frequency bands plus the spectral
centroid, then compares that to what it learned during calibration (nearest-centroid
classifier). Before calibration it falls back to a simple rule based on brightness.

Syllables spoken within 0.24 s of each other count as a run, which is how "paa-paa"
becomes a double jump and "ta-ta-ta-ta" becomes a long dash.

Audio is captured in an AudioWorklet so drawing can never delay it, and the game's own
sound effects briefly raise the detection threshold so Pip does not hear himself.

## If it does not respond well

| Problem | Fix |
| --- | --- |
| Nothing is heard | Allow microphone access (Windows: Settings ▸ Privacy & security ▸ Microphone ▸ "Let desktop apps access your microphone"). Check the green mic dot and level meter at the top right. |
| Misses quiet sounds | Move the **Mic sensitivity** slider right, or say the sounds more crisply. |
| Triggers on background noise | Move the slider left, and use headphones. |
| Mixes up kaa and ta | Run **Teach Pip my voice** again and exaggerate the difference. |
| Double jump fires when you meant one jump | Leave a clear pause (over half a second) between separate "paa"s. |

## Tuning

* Level layout: `level.ts` — each section is text, `#` ground, `C` crate, `B` blob,
  `S` beetle, `*` seed, `^` thorns, `~` crumbling bridge, `L` lantern, `w` Gentle-mode
  waiting spot, `1`-`4` hint signs, `G` goal.
* Physics (gravity, jump height, dash speed, slash reach): the constants at the top of `engine.ts`.
* Run speeds per mode: `RUN_SPEED` in `engine.ts`.
* Sounds: `sfx.ts`.
